@echo off
setlocal EnableExtensions DisableDelayedExpansion

set "APP=%~1"
set "BASE=%~2"
set "REPORTS=%~3"
if "%APP%"=="" set "APP=%CD%"
if "%BASE%"=="" set "BASE=%APP%\.."
if "%REPORTS%"=="" set "REPORTS=%APP%\shared_data\reports"

set "TOOLS=%APP%\tools"
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%TOOLS%" mkdir "%TOOLS%" >nul 2>nul

set "RESULT=%REPORTS%\BALI_V035_AUTO_SCORECARD_PARSER_FIX_RESULT.txt"
set "STATUS_TXT=%REPORTS%\BALI_CAPABILITY_STATUS_V035.txt"
set "STATUS_MD=%REPORTS%\BALI_CAPABILITY_STATUS_V035.md"
set "STATUS_JSON=%REPORTS%\BALI_CAPABILITY_STATUS_V035.json"
set "MARKER=%TOOLS%\V035_AUTO_SCORECARD_PARSER_FIX_MARKER.txt"

set "LATEST_STATUS_REPORT="
for /f "delims=" %%F in ('dir /b /a-d /o-d "%REPORTS%\BALI_CHATGPT_STATUS_REPORT*.txt" 2^>nul') do (
  if not defined LATEST_STATUS_REPORT set "LATEST_STATUS_REPORT=%REPORTS%\%%F"
)

set "REAL_DATA_GATE_LINE=Gate: UNKNOWN"
set "RAW_DATA_GATE_LINE=Raw data gate: UNKNOWN"
set "WARNING_LINE=Warning: UNKNOWN"
set "PAPER_LINE=Paper shadow rows: UNKNOWN"
set "BACKTEST_LINE=Backtest walk-forward rows: UNKNOWN"
set "BACKTEST_GATE_LINE=Backtest Gate: UNKNOWN"
set "CHAMPION_LINE=Champion proof gate: UNKNOWN"
set "RISK_LINE=Risk Police: UNKNOWN"
set "LIVE_LINE=Live orders: OFF"
set "KEY_LINE=API keys: NONE"
set "PAPER_STATUS_LINE=Paper Shadow: UNKNOWN"

rem Read lines with CALL-safe subroutines. Avoid complex FOR /F delimiters.
call :first_line "Gate:" REAL_DATA_GATE_LINE "Gate: UNKNOWN"
call :first_line "Raw data gate:" RAW_DATA_GATE_LINE "Raw data gate: UNKNOWN"
call :first_line "Warning:" WARNING_LINE "Warning: UNKNOWN"
call :first_line "Paper shadow rows:" PAPER_LINE "Paper shadow rows: UNKNOWN"
call :first_line "Backtest walk-forward rows:" BACKTEST_LINE "Backtest walk-forward rows: UNKNOWN"
call :first_line "Backtest Gate:" BACKTEST_GATE_LINE "Backtest Gate: UNKNOWN"
call :first_line "Champion proof gate:" CHAMPION_LINE "Champion proof gate: UNKNOWN"
call :first_line "Risk Police:" RISK_LINE "Risk Police: UNKNOWN"
call :first_line "Live orders:" LIVE_LINE "Live orders: OFF"
call :first_line "API keys:" KEY_LINE "API keys: NONE"
call :first_line "Paper Shadow:" PAPER_STATUS_LINE "Paper Shadow: UNKNOWN"

goto :after_subs

:first_line
set "PATTERN=%~1"
set "VAR=%~2"
set "DEFAULT=%~3"
set "%VAR%=%DEFAULT%"
if not defined LATEST_STATUS_REPORT exit /b 0
if not exist "%LATEST_STATUS_REPORT%" exit /b 0
for /f "usebackq delims=" %%L in (`findstr /c:"%PATTERN%" "%LATEST_STATUS_REPORT%" 2^>nul`) do (
  set "%VAR%=%%L"
  exit /b 0
)
exit /b 0

:after_subs

set "EDGE_STATE=UNKNOWN"
echo %BACKTEST_GATE_LINE% | findstr /c:"EDGE_NOT_PROVEN" >nul && set "EDGE_STATE=WALK_FORWARD_RECORDED_EDGE_NOT_PROVEN"
echo %BACKTEST_GATE_LINE% | findstr /c:"NO_TRADES_YET" >nul && set "EDGE_STATE=WALK_FORWARD_RECORDED_NO_TRADES_YET"
echo %BACKTEST_GATE_LINE% | findstr /c:"PROVEN" >nul && echo %BACKTEST_GATE_LINE% | findstr /v /c:"NOT_PROVEN" >nul && set "EDGE_STATE=EDGE_POSSIBLY_PROVEN_REVIEW_REQUIRED"

set "CHAMPION_CLAIM_ALLOWED=False"
echo %CHAMPION_LINE% | findstr /i /c:"champion_claim_allowed=True" >nul && set "CHAMPION_CLAIM_ALLOWED=True"
echo %BACKTEST_GATE_LINE% | findstr /i /c:"champion_claim_allowed=True" >nul && set "CHAMPION_CLAIM_ALLOWED=True"

set "EVIDENCE_SCORECARD=BLOCK"
set "CHAMPION_NOMINATION=CHAMPION_NOMINATION_BLOCKED"
set "LIVE_ORDERS_ALLOWED=False"
if /i "%CHAMPION_CLAIM_ALLOWED%"=="True" (
  set "EVIDENCE_SCORECARD=REVIEW_REQUIRED_NOT_AUTO_PASS"
  set "CHAMPION_NOMINATION=HUMAN_REVIEW_REQUIRED"
)

> "%RESULT%" echo BALI V035 AUTO SCORECARD PARSER FIX RESULT
>> "%RESULT%" echo Generated: %DATE% %TIME%
>> "%RESULT%" echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
>> "%RESULT%" echo VERSION=V035_AUTO_SCORECARD_PARSER_FIX_NO_PYTHON
>> "%RESULT%" echo PYTHON_USED=NO
>> "%RESULT%" echo UPDATE_DOCK_USED=NO
>> "%RESULT%" echo PARSER=SAFE_FINDSTR_NO_COMPLEX_DELIMS
>> "%RESULT%" echo APP=%APP%
>> "%RESULT%" echo BASE=%BASE%
>> "%RESULT%" echo REPORTS=%REPORTS%
>> "%RESULT%" echo LATEST_STATUS_REPORT=%LATEST_STATUS_REPORT%
>> "%RESULT%" echo REAL_DATA_GATE_LINE=%REAL_DATA_GATE_LINE%
>> "%RESULT%" echo RAW_DATA_GATE_LINE=%RAW_DATA_GATE_LINE%
>> "%RESULT%" echo WARNING_LINE=%WARNING_LINE%
>> "%RESULT%" echo PAPER_STATUS_LINE=%PAPER_STATUS_LINE%
>> "%RESULT%" echo PAPER_EVIDENCE=%PAPER_LINE%
>> "%RESULT%" echo BACKTEST_EVIDENCE=%BACKTEST_LINE%
>> "%RESULT%" echo BACKTEST_GATE_LINE=%BACKTEST_GATE_LINE%
>> "%RESULT%" echo EDGE_STATE=%EDGE_STATE%
>> "%RESULT%" echo CHAMPION_LINE=%CHAMPION_LINE%
>> "%RESULT%" echo CHAMPION_CLAIM_ALLOWED=%CHAMPION_CLAIM_ALLOWED%
>> "%RESULT%" echo RISK_LINE=%RISK_LINE%
>> "%RESULT%" echo EVIDENCE_SCORECARD=%EVIDENCE_SCORECARD%
>> "%RESULT%" echo CHAMPION_NOMINATION=%CHAMPION_NOMINATION%
>> "%RESULT%" echo LIVE_ORDERS_ALLOWED=%LIVE_ORDERS_ALLOWED%
>> "%RESULT%" echo RESULT=PASS_V035_AUTO_SCORECARD_PARSER_FIX_NO_PYTHON

> "%STATUS_TXT%" echo INSTALLED_CAPABILITY=V035_AUTO_SCORECARD_PARSER_FIX_NO_PYTHON
>> "%STATUS_TXT%" echo EVIDENCE_SCORECARD=%EVIDENCE_SCORECARD%
>> "%STATUS_TXT%" echo CHAMPION_NOMINATION=%CHAMPION_NOMINATION%
>> "%STATUS_TXT%" echo EDGE_STATE=%EDGE_STATE%
>> "%STATUS_TXT%" echo CHAMPION_CLAIM_ALLOWED=%CHAMPION_CLAIM_ALLOWED%
>> "%STATUS_TXT%" echo LIVE_ORDERS_ALLOWED=%LIVE_ORDERS_ALLOWED%
>> "%STATUS_TXT%" echo SOURCE=%LATEST_STATUS_REPORT%

> "%STATUS_MD%" echo # Bali Capability Status V035
>> "%STATUS_MD%" echo.
>> "%STATUS_MD%" echo - Installed capability: V035 auto scorecard parser fix no Python
>> "%STATUS_MD%" echo - Evidence scorecard: %EVIDENCE_SCORECARD%
>> "%STATUS_MD%" echo - Champion nomination: %CHAMPION_NOMINATION%
>> "%STATUS_MD%" echo - Edge state: %EDGE_STATE%
>> "%STATUS_MD%" echo - Champion claim allowed: %CHAMPION_CLAIM_ALLOWED%
>> "%STATUS_MD%" echo - Live orders allowed: %LIVE_ORDERS_ALLOWED%
>> "%STATUS_MD%" echo - Source: %LATEST_STATUS_REPORT%

> "%STATUS_JSON%" echo {
>> "%STATUS_JSON%" echo   "version": "V035_AUTO_SCORECARD_PARSER_FIX_NO_PYTHON",
>> "%STATUS_JSON%" echo   "python_used": false,
>> "%STATUS_JSON%" echo   "update_dock_used": false,
>> "%STATUS_JSON%" echo   "evidence_scorecard": "%EVIDENCE_SCORECARD%",
>> "%STATUS_JSON%" echo   "champion_nomination": "%CHAMPION_NOMINATION%",
>> "%STATUS_JSON%" echo   "edge_state": "%EDGE_STATE%",
>> "%STATUS_JSON%" echo   "champion_claim_allowed": "%CHAMPION_CLAIM_ALLOWED%",
>> "%STATUS_JSON%" echo   "live_orders_allowed": "%LIVE_ORDERS_ALLOWED%"
>> "%STATUS_JSON%" echo }

> "%MARKER%" echo VERSION=V035_AUTO_SCORECARD_PARSER_FIX_NO_PYTHON
>> "%MARKER%" echo PYTHON_USED=NO
>> "%MARKER%" echo UPDATE_DOCK_USED=NO
>> "%MARKER%" echo RESULT=PASS

exit /b 0
