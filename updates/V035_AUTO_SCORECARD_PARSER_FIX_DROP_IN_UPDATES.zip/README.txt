V035 Auto Scorecard Parser Fix

Drop this ZIP into the outer updates folder and start the real Forever starter.

Required folder:
C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\updates

This patch uses no Python and no Update Dock. It writes parser-safe scorecard reports and keeps live orders OFF, no API keys, and Champion nomination blocked unless evidence is proven.
