@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "APP=%~1"
set "BASE=%~2"
set "REPORTS=%~3"
if "%APP%"=="" set "APP=%CD%"
if "%BASE%"=="" set "BASE=%APP%\.."
if "%REPORTS%"=="" set "REPORTS=%APP%\shared_data\reports"
set "TOOLS=%APP%\tools"
set "VERSION=V034_AUTO_EVIDENCE_SCORECARD_REFRESH_NO_PYTHON"
set "PATCH_RESULT=%REPORTS%\BALI_V034_AUTO_EVIDENCE_SCORECARD_REFRESH_RESULT.txt"
set "CAP_TXT=%REPORTS%\BALI_CAPABILITY_STATUS_V034.txt"
set "CAP_MD=%REPORTS%\BALI_CAPABILITY_STATUS_V034.md"
set "CAP_JSON=%REPORTS%\BALI_CAPABILITY_STATUS_V034.json"
set "MARKER=%TOOLS%\V034_AUTO_EVIDENCE_SCORECARD_REFRESH_MARKER.txt"
set "LATEST_STATUS="

if not exist "%TOOLS%" mkdir "%TOOLS%" >nul 2>nul
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul

for /f "delims=" %%F in ('dir /b /a-d /od "%REPORTS%\BALI_CHATGPT_STATUS_REPORT_*.txt" 2^>nul') do set "LATEST_STATUS=%REPORTS%\%%F"
if not defined LATEST_STATUS (
  for /f "delims=" %%F in ('dir /b /a-d /od "%REPORTS%\BALI_CHATGPT_STATUS_REPORT*.txt" 2^>nul') do set "LATEST_STATUS=%REPORTS%\%%F"
)

set "REAL_DATA_GATE=UNKNOWN"
set "RAW_DATA_GATE=UNKNOWN"
set "PAPER_ROWS=UNKNOWN"
set "BACKTEST_ROWS=UNKNOWN"
set "EDGE_STATE=UNKNOWN"
set "CHAMPION_ALLOWED=False"
set "LIVE_ORDERS=OFF"
set "API_KEYS=NONE"
set "RISK_POLICE=ARMED"
set "SCORECARD=BLOCK"
set "NOMINATION=CHAMPION_NOMINATION_BLOCKED"

if defined LATEST_STATUS (
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Gate:" "%LATEST_STATUS%" 2^>nul') do if "!REAL_DATA_GATE!"=="UNKNOWN" set "REAL_DATA_GATE=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Raw data gate:" "%LATEST_STATUS%" 2^>nul') do set "RAW_DATA_GATE=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Paper shadow rows:" "%LATEST_STATUS%" 2^>nul') do set "PAPER_ROWS=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Backtest walk-forward rows:" "%LATEST_STATUS%" 2^>nul') do set "BACKTEST_ROWS=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Live orders:" "%LATEST_STATUS%" 2^>nul') do set "LIVE_ORDERS=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"API keys:" "%LATEST_STATUS%" 2^>nul') do set "API_KEYS=%%B"
  for /f "tokens=1,* delims=:" %%A in ('findstr /b /c:"Risk Police:" "%LATEST_STATUS%" 2^>nul') do set "RISK_POLICE=%%B"
  for /f "tokens=1,* delims:=|" %%A in ('findstr /c:"Backtest Gate:" "%LATEST_STATUS%" 2^>nul') do set "EDGE_STATE=%%B"
  findstr /i /c:"champion_claim_allowed=True" "%LATEST_STATUS%" >nul 2>nul && set "CHAMPION_ALLOWED=True"
  findstr /i /c:"WALK_FORWARD_RECORDED_EDGE_PROVEN" "%LATEST_STATUS%" >nul 2>nul && set "SCORECARD=REVIEW_REQUIRED_EDGE_PROVEN_TEXT_FOUND"
)

rem Hard safety override: no live trading path is allowed in this patch.
if /i not "%CHAMPION_ALLOWED%"=="True" set "SCORECARD=BLOCK"
if /i not "%CHAMPION_ALLOWED%"=="True" set "NOMINATION=CHAMPION_NOMINATION_BLOCKED"

(
  echo BALI V034 AUTO EVIDENCE SCORECARD REFRESH RESULT
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo VERSION=%VERSION%
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo APP=%APP%
  echo BASE=%BASE%
  echo REPORTS=%REPORTS%
  echo LATEST_STATUS_REPORT=%LATEST_STATUS%
  echo REAL_DATA_GATE=%REAL_DATA_GATE%
  echo RAW_DATA_GATE=%RAW_DATA_GATE%
  echo PAPER_EVIDENCE=Paper shadow rows:%PAPER_ROWS%
  echo BACKTEST_EVIDENCE=Backtest walk-forward rows:%BACKTEST_ROWS%
  echo EDGE_STATE=%EDGE_STATE%
  echo CHAMPION_CLAIM_ALLOWED=%CHAMPION_ALLOWED%
  echo EVIDENCE_SCORECARD=%SCORECARD%
  echo CHAMPION_NOMINATION=%NOMINATION%
  echo LIVE_ORDERS_ALLOWED=False
  echo RESULT=PASS_V034_AUTO_EVIDENCE_SCORECARD_REFRESH_NO_PYTHON
) > "%PATCH_RESULT%"

(
  echo BALI CAPABILITY STATUS V034
  echo Generated: %DATE% %TIME%
  echo VERSION=%VERSION%
  echo CORE_VERSION_LABEL=V015A_BACKTEST_WALK_FORWARD_GATE
  echo INSTALLED_CAPABILITY=V016_NATIVE_EVIDENCE_SCORECARD_PANEL_NO_PYTHON
  echo PATCH_LANE=V031_PLUS_FOREVER_STARTER_AUTOPATCH
  echo AUTOPATCH_STANDARD=VALID_BALI_AUTO_PATCH_MANIFEST_TXT_AND_AUTO_PATCH_INSTALL_BAT
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo REAL_DATA_GATE=%REAL_DATA_GATE%
  echo RAW_DATA_GATE=%RAW_DATA_GATE%
  echo PAPER_EVIDENCE=Paper shadow rows:%PAPER_ROWS%
  echo BACKTEST_EVIDENCE=Backtest walk-forward rows:%BACKTEST_ROWS%
  echo EDGE_STATE=%EDGE_STATE%
  echo EVIDENCE_SCORECARD=%SCORECARD%
  echo CHAMPION_NOMINATION=%NOMINATION%
  echo CHAMPION_CLAIM_ALLOWED=%CHAMPION_ALLOWED%
  echo LIVE_ORDERS_ALLOWED=False
  echo SOURCE_STATUS_REPORT=%LATEST_STATUS%
) > "%CAP_TXT%"

(
  echo # Bali Capability Status V034
  echo.
  echo - Version: %VERSION%
  echo - Patch lane: V031+ Forever starter autopatch
  echo - Python used: NO
  echo - Update Dock used: NO
  echo - Real data gate: %REAL_DATA_GATE%
  echo - Raw data gate: %RAW_DATA_GATE%
  echo - Paper evidence: Paper shadow rows:%PAPER_ROWS%
  echo - Backtest evidence: Backtest walk-forward rows:%BACKTEST_ROWS%
  echo - Evidence scorecard: %SCORECARD%
  echo - Champion nomination: %NOMINATION%
  echo - Live orders allowed: False
) > "%CAP_MD%"

(
  echo {
  echo   "version": "%VERSION%",
  echo   "python_used": "NO",
  echo   "update_dock_used": "NO",
  echo   "patch_lane": "V031_PLUS_FOREVER_STARTER_AUTOPATCH",
  echo   "evidence_scorecard": "%SCORECARD%",
  echo   "champion_nomination": "%NOMINATION%",
  echo   "champion_claim_allowed": "%CHAMPION_ALLOWED%",
  echo   "live_orders_allowed": false
  echo }
) > "%CAP_JSON%"

(
  echo VERSION=%VERSION%
  echo INSTALLED=YES
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo RESULT=PASS
) > "%MARKER%"

type "%PATCH_RESULT%"
exit /b 0
