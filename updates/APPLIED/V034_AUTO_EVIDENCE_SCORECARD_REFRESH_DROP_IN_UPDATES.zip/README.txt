V034_AUTO_EVIDENCE_SCORECARD_REFRESH_NO_PYTHON

Drop this ZIP into:
C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\updates

Then launch only:
C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\BALI_THEMED_FOREVER_STARTER.bat

The V031+ autopatch preflight should apply this patch before Bali starts.

Safety: no Python, no Update Dock, no live orders, no API keys, no Champion unlock.
