@echo off
setlocal EnableExtensions
set "APP=%~1"
set "BASE=%~2"
set "REPORTS=%~3"
if "%APP%"=="" exit /b 11
if "%BASE%"=="" exit /b 12
if "%REPORTS%"=="" exit /b 13
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%APP%\tools" mkdir "%APP%\tools" >nul 2>nul
(
  echo BALI V031 TEST PATCH INSTALL RESULT
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo VERSION=V031_TEST_PATCH_AUTOPATCH_FORMAT
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo APP=%APP%
  echo BASE=%BASE%
  echo RESULT=PASS_V031_TEST_PATCH_INSTALLED
) > "%REPORTS%\BALI_V031_TEST_PATCH_RESULT.txt"
(
  echo V031_TEST_PATCH_MARKER=PASS
  echo Generated=%DATE% %TIME%
) > "%APP%\tools\V031_TEST_PATCH_MARKER.txt"
echo PATCH_PAYLOAD_RESULT=PASS_V031_TEST_PATCH_INSTALLED
exit /b 0
