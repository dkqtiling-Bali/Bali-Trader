This ZIP is a clean V031 auto-patch format test. Put it in the outer updates folder and launch BALI_THEMED_FOREVER_STARTER.bat after installing V031.
