@echo off
setlocal EnableExtensions
set "APP=%~1"
set "BASE=%~2"
set "REPORTS=%~3"
if "%APP%"=="" exit /b 2
if "%BASE%"=="" exit /b 2
if "%REPORTS%"=="" set "REPORTS=%APP%\shared_data\reports"
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%APP%\tools" mkdir "%APP%\tools" >nul 2>nul
> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo BALI V036 TEST PATCH RESULT
>> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo Generated: %DATE% %TIME%
>> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo VERSION=V036_VISIBLE_AUTOPATCH_TEST_PATCH
>> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo PYTHON_USED=NO
>> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo UPDATE_DOCK_USED=NO
>> "%REPORTS%\BALI_V036_TEST_PATCH_RESULT.txt" echo RESULT=PASS_V036_TEST_PATCH_INSTALLED
> "%APP%\tools\V036_TEST_PATCH_MARKER.txt" echo V036_TEST_PATCH_MARKER=PASS
>> "%APP%\tools\V036_TEST_PATCH_MARKER.txt" echo Generated=%DATE% %TIME%
echo PATCH_PAYLOAD_RESULT=PASS_V036_TEST_PATCH_INSTALLED
exit /b 0
