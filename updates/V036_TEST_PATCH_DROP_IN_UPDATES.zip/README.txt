Drop this ZIP into the outer updates folder, then start BALI_THEMED_FOREVER_STARTER.bat. V036 should open a visible autopatch report and move this ZIP to updates\APPLIED.
