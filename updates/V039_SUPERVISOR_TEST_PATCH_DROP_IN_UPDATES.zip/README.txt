Drop this ZIP into the outer updates folder, then run Bali Supervisor Mission Control.
