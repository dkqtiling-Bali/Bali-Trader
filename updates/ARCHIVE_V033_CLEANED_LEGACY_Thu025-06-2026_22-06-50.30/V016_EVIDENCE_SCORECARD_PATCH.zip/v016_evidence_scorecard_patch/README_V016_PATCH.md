# V016 Evidence Scorecard + Champion Council Gate

## Purpose

V016 adds a hard evidence scorecard in front of Champion Council nomination. It does not enable live trading. It does not use API keys. It does not allow fake, offline, demo, synthetic, or stale rows to score.

Current V015A status is healthy for data collection and safety, but not edge-proven. In the supplied report, V016 correctly blocks champion nomination because backtest/walk-forward evidence is repeated only 4 times, walk-forward averages are negative, visible paper-shadow rows are stand-aside only, and the existing gate still says `WALK_FORWARD_RECORDED_EDGE_NOT_PROVEN`.

## Files

- `evidence_scorecard_v016.py` - drop-in Python module and CLI.
- `V016_SCORECARD_SAMPLE.json` - sample result from the supplied Bali report.
- `V016_SCORECARD_SAMPLE.md` - markdown sample report.
- `integration_snippet_v016.py` - safe integration example for a dashboard/report generator.
- `test_v016_evidence_scorecard.py` - minimal regression tests.

## Safety invariants

V016 must keep these true:

- Live orders remain OFF.
- No API keys are introduced.
- Champion lock remains LOCKED.
- Risk Police remains ARMED.
- Public data research only.
- Real-live-data gate remains enforced.
- Champion claim is always false from this module.
- Nomination is blocked unless repeated backtest/walk-forward and paper-shadow evidence exists.

## CLI examples

Run against a compact status report:

```bash
python evidence_scorecard_v016.py --status-report Bali.txt --out-json shared_data/reports/v016_evidence_scorecard.json --out-md shared_data/reports/v016_evidence_scorecard.md
```

Run against ledgers if your app has CSV files:

```bash
python evidence_scorecard_v016.py \
  --live-data-guard-csv shared_data/live_data_guard.csv \
  --paper-shadow-csv shared_data/paper_shadow.csv \
  --backtest-csv shared_data/backtest_walk_forward.csv \
  --out-json shared_data/reports/v016_evidence_scorecard.json \
  --out-md shared_data/reports/v016_evidence_scorecard.md
```

The CLI returns exit code `1` when nomination is blocked. That is expected and healthy when evidence is insufficient.

## Suggested integration points

1. Copy `evidence_scorecard_v016.py` into your Bali app root or a `bali_modules/` folder.
2. Call it after V015A writes backtest/walk-forward rows and before the report generator writes the final status report.
3. Surface these fields in the dashboard:
   - `version`
   - `gate`
   - `overall_status`
   - `nomination_allowed`
   - `champion_claim_allowed`
   - `summary.blocking_checks`
4. Continue to display the old V015A backtest gate, but add the stricter V016 result beneath it.
5. Never wire V016 to live order execution. It is a nomination-review gate only.

## Expected current result from the supplied report

- Overall status: `BLOCK`
- Gate: `CHAMPION_NOMINATION_BLOCKED`
- Nomination allowed: `false`
- Champion claim allowed: `false`

Main blocking checks:

- Paper Shadow repeated rows: 31 observed, 50 required.
- Paper Shadow closed trade evidence: 0 visible, 10 required.
- Backtest/WF repeated rows: 4 observed, 12 required.
- Backtest/WF positive repeated edge: 0 observed, 8 required.
- Distinct backtest IDs: 4 observed, 12 required.
- Backtest edge not proven flag is still present.

## V016 completion criteria

V016 is installed when the doctor/report output includes a section like:

```text
Evidence Scorecard: V016_EVIDENCE_SCORECARD_CHAMPION_COUNCIL_GATE | gate=CHAMPION_NOMINATION_BLOCKED | nomination_allowed=False | champion_claim_allowed=False
Champion Council Gate: LOCKED_EVIDENCE_SCORECARD_REQUIRED | approvals=0/3 | live_orders=OFF | risk_police=ARMED
```

If the system later gathers enough repeated evidence, V016 may set `nomination_allowed=True`, but `champion_claim_allowed` must remain `False` until separate human approval logic records 3/3 approvals. This patch does not implement champion approval, live trading, API keys, or order placement.
