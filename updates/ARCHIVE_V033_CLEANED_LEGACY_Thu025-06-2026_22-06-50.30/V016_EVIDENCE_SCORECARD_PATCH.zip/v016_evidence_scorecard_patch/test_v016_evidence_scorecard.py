from pathlib import Path

from evidence_scorecard_v016 import (
    NOMINATION_BLOCKED,
    evaluate_status_report,
    parse_status_report,
)


def test_current_supplied_report_blocks_nomination():
    report_path = Path(__file__).resolve().parent.parent / "Bali.txt"
    if not report_path.exists():
        report_path = Path("/mnt/data/Bali.txt")
    parsed = parse_status_report(report_path.read_text(encoding="utf-8"))
    scorecard = evaluate_status_report(parsed)
    assert scorecard.gate == NOMINATION_BLOCKED
    assert scorecard.nomination_allowed is False
    assert scorecard.champion_claim_allowed is False
    blocking = set(scorecard.summary["blocking_checks"])
    assert "Backtest/WF repeated rows" in blocking
    assert "Paper Shadow closed trade evidence" in blocking
    assert "Backtest edge not proven flag cleared" in blocking


def test_real_live_gate_parse():
    text = """
Generated UTC: 2026-06-25T09:40:52+00:00
Version: V015A_BACKTEST_WALK_FORWARD_GATE
Live orders: OFF
Champion lock: LOCKED / approved 0/3
API keys: NONE / private exchange endpoints not used
Mode: PUBLIC_DATA_RESEARCH_ONLY
Gate: PASS_RECENT_REAL_LIVE_DATA
Raw data gate: ENFORCED_PASS_REAL_LIVE_DATA_ONLY
Warning: OK
Stale seconds: 0
Feed source: https://data-api.binance.vision
Ignored recent offline_demo rows: 0
COUNTS
Market ticks: 2916
Live data guard: 88
Learning cycles: 486
Paper shadow rows: 31
Candle rows total: 258
Candle proof rows: 23
Universe scan ledger rows: 920
Universe latest batch visible rows: 40
Backtest walk-forward rows: 4

PAPER / RISK STATUS
Paper Shadow: PAPER_SHADOW_ONLINE | last_action=STAND_ASIDE_SIMULATED | open_position=NONE
Candle Harvester: CANDLE_HARVESTER_ONLINE | last_new_rows=12 | total_rows=258
Universe Scanner: UNIVERSE_SCANNER_ONLINE | latest_batch_rows=40 | ledger_rows=920
Backtest Gate: BACKTEST_WALK_FORWARD_RECORDED | gate=WALK_FORWARD_RECORDED_EDGE_NOT_PROVEN | symbol=BTCUSDT | interval=1m
Risk Police: ARMED
champion_claim_allowed=False
"""
    parsed = parse_status_report(text)
    scorecard = evaluate_status_report(parsed)
    assert scorecard.summary["real_live_gate"] == "PASS_RECENT_REAL_LIVE_DATA"
    assert scorecard.champion_claim_allowed is False
    assert scorecard.nomination_allowed is False
