# V016B Integration Notes

## Diagnosis from the screen

The dashboard is rendering, but one of its JavaScript calls cannot fetch backend data. Because the UI still says `V015A_BACKTEST_WALK_FORWARD_GATE`, this is probably not yet a confirmed V016 dashboard integration. It is a local dashboard/API connection issue.

## First checks

Run these in the Bali app terminal:

```bash
python local_connection_doctor_v016b.py --base http://127.0.0.1:8000
python local_connection_doctor_v016b.py --base http://127.0.0.1:5000
python local_connection_doctor_v016b.py --base http://127.0.0.1:7860
```

If all fail, the backend server is probably stopped or on a different port.

## Frontend patch

Load `dashboard_fetch_guard_v016b.js` in the dashboard HTML before the main dashboard script:

```html
<script src="/static/js/dashboard_fetch_guard_v016b.js"></script>
```

Replace direct fetch calls:

```javascript
const response = await fetch('/api/status');
const data = await response.json();
```

with:

```javascript
const result = await baliFetchStatusV016B();
if (!result.ok) {
  renderBaliConnectionIssueV016B('connection-status', result);
  return;
}
const data = result.data;
```

## Backend patch

If `/api/health` or `/api/status` is missing, add the example routes from `backend_health_routes_v016b.py`.

## Do not do this

- Do not add mock status data to hide the fetch failure.
- Do not mark the real-live-data gate as passing unless the backend proves it.
- Do not allow champion nomination from cached UI-only values.
- Do not add exchange API keys.
- Do not enable live orders.
