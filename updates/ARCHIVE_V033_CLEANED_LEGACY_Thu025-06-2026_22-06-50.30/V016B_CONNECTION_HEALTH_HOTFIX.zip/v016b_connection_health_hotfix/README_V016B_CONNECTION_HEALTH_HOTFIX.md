# V016B Connection Health Hotfix

## Purpose

This patch is for the dashboard symptom:

```text
Connection issue
TypeError: Failed to fetch
```

It is a UI/backend reliability patch only. It does not enable live trading, does not introduce API keys, does not use exchange-private endpoints, and does not generate fake/demo/offline scoring rows.

## What the error usually means

`TypeError: Failed to fetch` is raised by the browser when JavaScript cannot receive a valid HTTP response. Common local causes:

1. The backend dashboard/API server is not running.
2. The frontend is calling the wrong host or port.
3. The backend route changed or is missing.
4. CORS blocked the request because the frontend and backend are on different origins.
5. The request timed out or the backend crashed mid-request.
6. Windows firewall or antivirus blocked the local port.

## Files

- `dashboard_fetch_guard_v016b.js` - safe browser fetch helper with same-origin first, localhost fallbacks, timeout, and no fake data fallback.
- `backend_health_routes_v016b.py` - small Flask-style health/status routes to paste into the backend if routes are missing.
- `local_connection_doctor_v016b.py` - local CLI checker for dashboard/API endpoints.
- `integration_notes_v016b.md` - copy/paste integration checklist.

## Safety invariants

This patch must keep all of these true:

- Live orders remain OFF.
- Champion lock remains LOCKED.
- API keys remain NONE.
- Public data research only.
- Real-live-data gate remains enforced.
- No fake/offline/demo scoring rows are created.
- Connection failure must display `CONNECTION_UNHEALTHY` rather than invent data.

## Quick install

1. Copy `dashboard_fetch_guard_v016b.js` into the dashboard static/js folder.
2. Load it before the dashboard code that calls `fetch(...)`.
3. Replace direct dashboard calls such as `fetch('/api/status')` with:

```javascript
const result = await baliFetchStatusV016B();
if (!result.ok) {
  renderConnectionIssue(result);
  return;
}
renderMissionControl(result.data);
```

4. If the backend lacks a simple health route, paste the safe route examples from `backend_health_routes_v016b.py` into the Flask app.
5. Run the local doctor:

```bash
python local_connection_doctor_v016b.py --base http://127.0.0.1:8000
```

Try other common ports if needed:

```bash
python local_connection_doctor_v016b.py --base http://127.0.0.1:5000
python local_connection_doctor_v016b.py --base http://127.0.0.1:7860
```

## Expected dashboard behavior after install

If the backend is healthy, the dashboard displays mission data normally.

If the backend is unreachable, the dashboard displays a clear status such as:

```text
Connection: CONNECTION_UNHEALTHY
Last attempted endpoint: http://127.0.0.1:8000/api/status
Error: Failed to fetch
Safety: live_orders=OFF | champion_lock=LOCKED | api_keys=NONE
```

No stale or fake replacement data should be shown.
