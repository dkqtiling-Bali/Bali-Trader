#!/usr/bin/env python3
"""
Local connection doctor for Bali dashboard/API.
Uses only local HTTP GET requests. No API keys. No exchange-private endpoints.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from typing import List, Optional


VERSION = "V016B_CONNECTION_HEALTH_HOTFIX"
DEFAULT_PATHS = ["/api/health", "/api/status", "/status", "/api/mission-control", "/mission-control/status"]


@dataclass
class Attempt:
    url: str
    ok: bool
    http_status: Optional[int]
    elapsed_ms: int
    error: Optional[str]
    content_type: Optional[str]
    body_preview: Optional[str]


def fetch_url(url: str, timeout: float) -> Attempt:
    started = time.time()
    try:
      request = urllib.request.Request(url, headers={"Accept": "application/json,text/plain,*/*"})
      with urllib.request.urlopen(request, timeout=timeout) as response:
          body = response.read(1200).decode("utf-8", errors="replace")
          elapsed_ms = int((time.time() - started) * 1000)
          return Attempt(
              url=url,
              ok=200 <= response.status < 300,
              http_status=response.status,
              elapsed_ms=elapsed_ms,
              error=None,
              content_type=response.headers.get("content-type"),
              body_preview=body[:500],
          )
    except urllib.error.HTTPError as exc:
      elapsed_ms = int((time.time() - started) * 1000)
      body = exc.read(500).decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
      return Attempt(url=url, ok=False, http_status=exc.code, elapsed_ms=elapsed_ms, error=str(exc), content_type=None, body_preview=body)
    except Exception as exc:
      elapsed_ms = int((time.time() - started) * 1000)
      return Attempt(url=url, ok=False, http_status=None, elapsed_ms=elapsed_ms, error=type(exc).__name__ + ": " + str(exc), content_type=None, body_preview=None)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Check local Bali dashboard/API connectivity.")
    parser.add_argument("--base", action="append", help="Base URL, for example http://127.0.0.1:8000. Can be repeated.")
    parser.add_argument("--timeout", type=float, default=4.5, help="HTTP timeout seconds.")
    parser.add_argument("--json", action="store_true", help="Print JSON only.")
    args = parser.parse_args(argv)

    bases = args.base or ["http://127.0.0.1:8000", "http://localhost:8000", "http://127.0.0.1:5000", "http://localhost:5000", "http://127.0.0.1:7860", "http://localhost:7860"]
    attempts: List[Attempt] = []

    for base in bases:
        clean = base.rstrip("/")
        for path in DEFAULT_PATHS:
            attempt = fetch_url(clean + path, args.timeout)
            attempts.append(attempt)
            if attempt.ok:
                break
        if attempts and attempts[-1].ok:
            break

    healthy = any(a.ok for a in attempts)
    payload = {
        "version": VERSION,
        "gate": "CONNECTION_HEALTHY_REAL_RESPONSE" if healthy else "CONNECTION_UNHEALTHY_NO_FAKE_DATA",
        "healthy": healthy,
        "safety": {
            "live_orders": "OFF",
            "champion_lock": "LOCKED",
            "api_keys": "NONE",
            "fake_scoring": "DISALLOWED",
        },
        "attempts": [asdict(a) for a in attempts],
    }

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(f"{VERSION} | gate={payload['gate']} | healthy={healthy}")
        for a in attempts:
            status = "PASS" if a.ok else "FAIL"
            print(f"- {status} {a.url} status={a.http_status} elapsed_ms={a.elapsed_ms} error={a.error}")
        print("Safety: live_orders=OFF | champion_lock=LOCKED | api_keys=NONE | fake_scoring=DISALLOWED")

    return 0 if healthy else 2


if __name__ == "__main__":
    raise SystemExit(main())
