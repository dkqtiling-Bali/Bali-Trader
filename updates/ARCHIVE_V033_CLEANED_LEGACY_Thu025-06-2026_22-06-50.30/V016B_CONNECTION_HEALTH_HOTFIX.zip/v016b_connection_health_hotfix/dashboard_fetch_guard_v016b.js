/*
V016B Bali dashboard fetch guard.
Safety: no live orders, no API keys, no fake/offline/demo fallback data.
*/

(function () {
  'use strict';

  const VERSION = 'V016B_CONNECTION_HEALTH_HOTFIX';

  function withTimeout(ms) {
    const controller = new AbortController();
    const timer = setTimeout(function () {
      controller.abort();
    }, ms);
    return { controller, timer };
  }

  function getCandidateBases() {
    const origin = window.location.origin;
    const candidates = [
      origin,
      'http://127.0.0.1:8000',
      'http://localhost:8000',
      'http://127.0.0.1:5000',
      'http://localhost:5000',
      'http://127.0.0.1:7860',
      'http://localhost:7860'
    ];
    return Array.from(new Set(candidates));
  }

  function normalizeBase(base) {
    return String(base || '').replace(/\/+$/, '');
  }

  async function fetchJsonWithTimeout(url, timeoutMs) {
    const timeout = withTimeout(timeoutMs || 4500);
    try {
      const response = await fetch(url, {
        method: 'GET',
        cache: 'no-store',
        signal: timeout.controller.signal,
        headers: { 'Accept': 'application/json' }
      });
      const contentType = response.headers.get('content-type') || '';
      let data = null;
      if (contentType.indexOf('application/json') >= 0) {
        data = await response.json();
      } else {
        data = { raw_text: await response.text() };
      }
      return {
        ok: response.ok,
        http_status: response.status,
        url: url,
        data: data,
        error: response.ok ? null : ('HTTP ' + response.status)
      };
    } catch (err) {
      return {
        ok: false,
        http_status: null,
        url: url,
        data: null,
        error: err && err.name === 'AbortError' ? 'FETCH_TIMEOUT' : String(err && err.message ? err.message : err)
      };
    } finally {
      clearTimeout(timeout.timer);
    }
  }

  async function baliFetchStatusV016B(options) {
    const opts = options || {};
    const paths = opts.paths || ['/api/status', '/status', '/api/mission-control', '/mission-control/status'];
    const bases = opts.bases || getCandidateBases();
    const timeoutMs = opts.timeoutMs || 4500;
    const attempts = [];

    for (const base of bases) {
      for (const path of paths) {
        const url = normalizeBase(base) + path;
        const result = await fetchJsonWithTimeout(url, timeoutMs);
        attempts.push({ url: url, ok: result.ok, http_status: result.http_status, error: result.error });
        if (result.ok) {
          return {
            ok: true,
            version: VERSION,
            gate: 'CONNECTION_HEALTHY_REAL_RESPONSE',
            url: url,
            attempts: attempts,
            data: result.data
          };
        }
      }
    }

    return {
      ok: false,
      version: VERSION,
      gate: 'CONNECTION_UNHEALTHY_NO_FAKE_DATA',
      safety: {
        live_orders: 'OFF',
        champion_lock: 'LOCKED',
        api_keys: 'NONE',
        fake_scoring: 'DISALLOWED'
      },
      attempts: attempts,
      error: attempts.length ? attempts[attempts.length - 1].error : 'NO_ATTEMPTS'
    };
  }

  function renderBaliConnectionIssueV016B(containerOrId, result) {
    const el = typeof containerOrId === 'string' ? document.getElementById(containerOrId) : containerOrId;
    if (!el) return;
    const attempts = result && result.attempts ? result.attempts : [];
    const last = attempts.length ? attempts[attempts.length - 1] : { url: 'none', error: 'none' };
    el.innerHTML = '';

    const box = document.createElement('div');
    box.setAttribute('data-bali-connection-health', 'unhealthy');
    box.style.border = '1px solid #aa7700';
    box.style.padding = '12px';
    box.style.borderRadius = '8px';
    box.style.margin = '8px 0';

    const title = document.createElement('strong');
    title.textContent = 'Connection issue - backend/API fetch failed';
    box.appendChild(title);

    const lines = [
      'Gate: CONNECTION_UNHEALTHY_NO_FAKE_DATA',
      'Last attempted endpoint: ' + last.url,
      'Error: ' + (last.error || 'unknown'),
      'Safety: live_orders=OFF | champion_lock=LOCKED | api_keys=NONE | fake_scoring=DISALLOWED'
    ];
    for (const line of lines) {
      const div = document.createElement('div');
      div.textContent = line;
      box.appendChild(div);
    }

    el.appendChild(box);
  }

  window.baliFetchStatusV016B = baliFetchStatusV016B;
  window.renderBaliConnectionIssueV016B = renderBaliConnectionIssueV016B;
})();
