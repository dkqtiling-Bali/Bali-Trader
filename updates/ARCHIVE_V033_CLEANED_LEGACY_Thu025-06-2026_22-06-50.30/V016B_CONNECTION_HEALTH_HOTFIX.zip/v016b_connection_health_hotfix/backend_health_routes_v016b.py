"""
V016B backend health route examples.
Paste into the existing Flask backend if equivalent routes do not already exist.
This file does not place orders, does not use API keys, and does not fetch private endpoints.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def build_safe_connection_health() -> Dict[str, Any]:
    return {
        "version": "V016B_CONNECTION_HEALTH_HOTFIX",
        "status": "OK_BACKEND_RESPONDING",
        "generated_utc": utc_now_iso(),
        "safety": {
            "live_orders": "OFF",
            "champion_lock": "LOCKED",
            "api_keys": "NONE",
            "private_exchange_endpoints": "NOT_USED",
            "fake_offline_demo_scoring": "DISALLOWED",
        },
    }


def read_latest_scorecard(reports_dir: str | Path = "shared_data/reports") -> Dict[str, Any]:
    """Return scorecard text only if a real generated file exists. No fake fallback."""
    reports_path = Path(reports_dir)
    md_path = reports_path / "v016_evidence_scorecard.md"
    json_path = reports_path / "v016_evidence_scorecard.json"
    if md_path.exists():
        return {"available": True, "format": "markdown", "path": str(md_path), "text": md_path.read_text(encoding="utf-8")}
    if json_path.exists():
        return {"available": True, "format": "json", "path": str(json_path), "text": json_path.read_text(encoding="utf-8")}
    return {"available": False, "reason": "NO_REAL_SCORECARD_FILE_FOUND"}


# Flask integration example:
#
# from flask import Flask, jsonify
# app = Flask(__name__)
#
# @app.get('/api/health')
# def api_health():
#     return jsonify(build_safe_connection_health())
#
# @app.get('/api/status')
# def api_status():
#     payload = build_safe_connection_health()
#     payload['evidence_scorecard'] = read_latest_scorecard('shared_data/reports')
#     return jsonify(payload)
#
# Optional CORS, only for local dashboard development:
# @app.after_request
# def add_local_cors_headers(response):
#     response.headers['Access-Control-Allow-Origin'] = '*'
#     response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
#     response.headers['Access-Control-Allow-Methods'] = 'GET, OPTIONS'
#     return response
