@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "BASE=%USERPROFILE%\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
set "ROOT=%BASE%\bali_rocket_crypto_command_v011b"
set "UPDATES=%BASE%\updates"
set "REPORTS=%ROOT%\shared_data\reports"
set "TOOLS=%ROOT%\tools\BALI_DASH_UPDATES_AUTO_DETECTOR"
set "DESKTOP=%USERPROFILE%\Desktop"
set "REPORT=%DESKTOP%\BALI_V027_DASH_AUTO_PATCH_FOREVER_FIX_REPORT.txt"

if not exist "%ROOT%" (
  echo BALI V027 DASH AUTO PATCH FOREVER FIX>"%REPORT%"
  echo RESULT=FAIL_ROOT_NOT_FOUND>>"%REPORT%"
  echo ROOT=%ROOT%>>"%REPORT%"
  start "" notepad "%REPORT%"
  exit /b 1
)

mkdir "%UPDATES%" 2>nul
mkdir "%UPDATES%\APPLIED" 2>nul
mkdir "%UPDATES%\QUARANTINE" 2>nul
mkdir "%REPORTS%" 2>nul
mkdir "%TOOLS%" 2>nul

copy /Y "%~dp0payload\BALI_FOREVER_ONE_CLICK_AUTOPATCH.bat" "%TOOLS%\BALI_FOREVER_ONE_CLICK_AUTOPATCH.bat" >nul
copy /Y "%~dp0payload\BALI_DASH_UPDATES_AUTO_DETECTOR_ONCE.bat" "%TOOLS%\BALI_DASH_UPDATES_AUTO_DETECTOR_ONCE.bat" >nul
copy /Y "%~dp0payload\BALI_CLEAR_AUTO_PATCH_LOCKS.bat" "%DESKTOP%\Bali Clear Auto Patch Launch Locks.bat" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='SilentlyContinue';" ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$tools='%TOOLS%'; $root='%ROOT%';" ^
  "$lnk=Join-Path $desktop 'Bali Forever Mission Control.lnk';" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$oldTarget=''; $oldArgs=''; $oldWork=''; $oldIcon='';" ^
  "if(Test-Path $lnk){$old=$shell.CreateShortcut($lnk); $oldTarget=$old.TargetPath; $oldArgs=$old.Arguments; $oldWork=$old.WorkingDirectory; $oldIcon=$old.IconLocation;}" ^
  "Set-Content -Path (Join-Path $tools 'BALI_ORIGINAL_SHORTCUT_TARGET.txt') -Value @('TARGET='+$oldTarget,'ARGS='+$oldArgs,'WORKDIR='+$oldWork,'ICON='+$oldIcon);" ^
  "$callFile=Join-Path $tools 'BALI_START_ORIGINAL_FOREVER.bat';" ^
  "$lines=@('@echo off','setlocal','set "ROOT=%ROOT%"');" ^
  "if($oldTarget -and (Test-Path $oldTarget) -and ($oldTarget -notlike '*BALI_FOREVER_ONE_CLICK_AUTOPATCH.bat')){$safeWork=if($oldWork){$oldWork}else{Split-Path $oldTarget}; $lines += 'cd /d "' + $safeWork + '"'; $lines += 'start "Bali Forever Core" /min "' + $oldTarget + '" ' + $oldArgs;} else {$lines += 'cd /d "%ROOT%"'; $lines += 'for %%F in (*.bat) do ('; $lines += '  findstr /I /C:"Bali Forever Starter" /C:"Dashboard opening at http://127.0.0.1:9061" "%%F" >nul 2>nul && start "Bali Forever Core" /min "%%F" && exit /b 0'; $lines += ')'; $lines += 'start "Bali Dashboard" "http://127.0.0.1:9061"';}" ^
  "Set-Content -Path $callFile -Value $lines -Encoding ASCII;" ^
  "$s=$shell.CreateShortcut($lnk); $s.TargetPath=Join-Path $tools 'BALI_FOREVER_ONE_CLICK_AUTOPATCH.bat'; $s.WorkingDirectory=$root; if($oldIcon){$s.IconLocation=$oldIcon}; $s.Save();"

(
  echo BALI V027 DASH AUTO PATCH FOREVER FIX
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo VERSION=V027_DASH_AUTO_PATCH_FOREVER_FIX_NO_PYTHON
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo ROOT=%ROOT%
  echo UPDATES=%UPDATES%
  echo WATCH_FOLDER=%UPDATES%
  echo APPLIED_FOLDER=%UPDATES%\APPLIED
  echo QUARANTINE_FOLDER=%UPDATES%\QUARANTINE
  echo TOOLS=%TOOLS%
  echo RETARGETED_ICON=%DESKTOP%\Bali Forever Mission Control.lnk
  echo FALLBACK_ONE_CLICK=%DESKTOP%\Bali Forever Mission Control - ONE CLICK.bat
  echo CLEAR_LOCK=%DESKTOP%\Bali Clear Auto Patch Launch Locks.bat
  echo BEHAVIOR=DOWNLOAD_ZIP_TO_OUTER_UPDATES_THEN_CLICK_BALI_FOREVER_MISSION_CONTROL
  echo DETECTOR=RUNS_BEFORE_DASHBOARD_START
  echo PATCH_FORMAT=BALI_PATCH_APPLY.bat_INSIDE_ZIP
  echo RESULT=PASS_V027_FOREVER_ICON_RETARGETED_TO_DASH_AUTO_PATCH_DETECTOR
)>"%REPORT%"

(
  echo @echo off
  echo call "%%USERPROFILE%%\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\bali_rocket_crypto_command_v011b\tools\BALI_DASH_UPDATES_AUTO_DETECTOR\BALI_FOREVER_ONE_CLICK_AUTOPATCH.bat"
)>"%DESKTOP%\Bali Forever Mission Control - ONE CLICK.bat"

copy /Y "%REPORT%" "%REPORTS%\BALI_V027_DASH_AUTO_PATCH_FOREVER_FIX_REPORT.txt" >nul
start "" notepad "%REPORT%"
exit /b 0
