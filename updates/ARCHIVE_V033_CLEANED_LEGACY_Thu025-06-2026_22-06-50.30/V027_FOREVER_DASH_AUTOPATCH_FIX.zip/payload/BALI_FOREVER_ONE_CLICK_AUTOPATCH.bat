@echo off
setlocal EnableExtensions
set "BASE=%USERPROFILE%\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
set "ROOT=%BASE%\bali_rocket_crypto_command_v011b"
set "TOOLS=%ROOT%\tools\BALI_DASH_UPDATES_AUTO_DETECTOR"
set "REPORTS=%ROOT%\shared_data\reports"
set "LOCK=%TEMP%\BALI_FOREVER_ONE_CLICK_AUTOPATCH.lock"
set "DASH=http://127.0.0.1:9061"

if exist "%LOCK%" (
  start "Bali Dashboard" "%DASH%"
  if exist "%REPORTS%\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt" start "" notepad "%REPORTS%\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt"
  exit /b 0
)

echo %DATE% %TIME%>"%LOCK%"

call "%TOOLS%\BALI_DASH_UPDATES_AUTO_DETECTOR_ONCE.bat"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; try{$r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:9061' -TimeoutSec 2; if($r.StatusCode -ge 200){$ok=$true}}catch{}; if($ok){exit 0}else{exit 1}"
if errorlevel 1 (
  if exist "%TOOLS%\BALI_START_ORIGINAL_FOREVER.bat" (
    start "Bali Forever Core" /min cmd /c call "%TOOLS%\BALI_START_ORIGINAL_FOREVER.bat"
  ) else (
    start "Bali Dashboard" "%DASH%"
  )
) else (
  start "Bali Dashboard" "%DASH%"
)

timeout /t 3 /nobreak >nul
start "Bali Dashboard" "%DASH%"
if exist "%REPORTS%\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt" start "" notepad "%REPORTS%\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt"

del /f /q "%LOCK%" >nul 2>nul
exit /b 0
