@echo off
setlocal
set "LOCK=%TEMP%\BALI_FOREVER_ONE_CLICK_AUTOPATCH.lock"
if exist "%LOCK%" del /f /q "%LOCK%" >nul 2>nul
echo Bali auto patch launch lock cleared.
pause
