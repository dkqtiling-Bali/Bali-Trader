@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "BASE=%USERPROFILE%\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
set "ROOT=%BASE%\bali_rocket_crypto_command_v011b"
set "UPDATES=%BASE%\updates"
set "APPLIED=%UPDATES%\APPLIED"
set "QUARANTINE=%UPDATES%\QUARANTINE"
set "REPORTS=%ROOT%\shared_data\reports"
set "REPORT=%REPORTS%\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt"
set "DESKTOP_REPORT=%USERPROFILE%\Desktop\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt"
set "TEMP_APPLY=%TEMP%\BALI_AUTO_PATCH_EXTRACT"

mkdir "%UPDATES%" 2>nul
mkdir "%APPLIED%" 2>nul
mkdir "%QUARANTINE%" 2>nul
mkdir "%REPORTS%" 2>nul
if exist "%TEMP_APPLY%" rmdir /s /q "%TEMP_APPLY%" >nul 2>nul
mkdir "%TEMP_APPLY%" 2>nul

set "SELECTED_FILE=%TEMP%\BALI_SELECTED_PATCH_PATH.txt"
set "PATCH_COUNT_FILE=%TEMP%\BALI_PATCH_COUNT.txt"
set "EXTRA_FILE=%TEMP%\BALI_EXTRA_PATCHES.txt"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='%UPDATES%'; $q='%QUARANTINE%'; $z=Get-ChildItem -LiteralPath $u -Filter *.zip -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending; Set-Content -Path '%PATCH_COUNT_FILE%' -Value $z.Count; if($z.Count -gt 0){Set-Content -Path '%SELECTED_FILE%' -Value $z[0].FullName; $z | Select-Object -Skip 1 | ForEach-Object { Move-Item -LiteralPath $_.FullName -Destination (Join-Path $q $_.Name) -Force; $_.FullName } | Set-Content -Path '%EXTRA_FILE%'} else {Set-Content -Path '%SELECTED_FILE%' -Value ''}"

set /p PATCH_COUNT=<"%PATCH_COUNT_FILE%"
set /p SELECTED=<"%SELECTED_FILE%"

(
  echo BALI DASH UPDATES AUTO DETECTOR REPORT
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo VERSION=V027_DASH_UPDATES_AUTO_DETECTOR_NO_PYTHON
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo WATCH_FOLDER=%UPDATES%
  echo PATCH_ZIP_COUNT=%PATCH_COUNT%
  echo SELECTED_PATCH=%SELECTED%
)>>"%REPORT%"

if "%SELECTED%"=="" (
  (
    echo RESULT=NO_PATCH_WAITING_DASH_OPEN_ONLY
  )>>"%REPORT%"
  copy /Y "%REPORT%" "%DESKTOP_REPORT%" >nul 2>nul
  exit /b 0
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "try{Expand-Archive -LiteralPath '%SELECTED%' -DestinationPath '%TEMP_APPLY%' -Force; exit 0}catch{exit 9}"
if errorlevel 1 (
  move /Y "%SELECTED%" "%QUARANTINE%\" >nul 2>nul
  (
    echo RESULT=FAIL_ZIP_EXTRACT_QUARANTINED
    echo QUARANTINE_FOLDER=%QUARANTINE%
  )>>"%REPORT%"
  copy /Y "%REPORT%" "%DESKTOP_REPORT%" >nul 2>nul
  exit /b 1
)

set "APPLY_FILE=%TEMP%\BALI_APPLY_BAT_PATH.txt"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root='%TEMP_APPLY%'; $patterns=@('BALI_PATCH_APPLY.bat','APPLY_PATCH.bat','BALI_ONE_CLICK_INSTALL*.bat','BALI_INSTALL*.bat','BALI_*NOW.bat'); $found=$null; foreach($p in $patterns){$found=Get-ChildItem -LiteralPath $root -Recurse -File -Filter $p -ErrorAction SilentlyContinue | Select-Object -First 1; if($found){break}}; if($found){Set-Content -Path '%APPLY_FILE%' -Value $found.FullName}else{Set-Content -Path '%APPLY_FILE%' -Value ''}"
set /p APPLY_BAT=<"%APPLY_FILE%"

if "%APPLY_BAT%"=="" (
  move /Y "%SELECTED%" "%QUARANTINE%\" >nul 2>nul
  (
    echo RESULT=FAIL_NO_BALI_PATCH_APPLY_BAT_FOUND_QUARANTINED
    echo REQUIRED_FORMAT=ZIP_MUST_CONTAIN_BALI_PATCH_APPLY.bat
    echo QUARANTINE_FOLDER=%QUARANTINE%
  )>>"%REPORT%"
  copy /Y "%REPORT%" "%DESKTOP_REPORT%" >nul 2>nul
  exit /b 1
)

(
  echo APPLY_BAT=%APPLY_BAT%
)>>"%REPORT%"

for %%A in ("%APPLY_BAT%") do set "APPLY_DIR=%%~dpA"
pushd "%APPLY_DIR%"
call "%APPLY_BAT%"
set "APPLY_ERROR=%ERRORLEVEL%"
popd

if not "%APPLY_ERROR%"=="0" (
  move /Y "%SELECTED%" "%QUARANTINE%\" >nul 2>nul
  (
    echo APPLY_EXIT_CODE=%APPLY_ERROR%
    echo RESULT=FAIL_PATCH_APPLY_QUARANTINED
    echo QUARANTINE_FOLDER=%QUARANTINE%
  )>>"%REPORT%"
  copy /Y "%REPORT%" "%DESKTOP_REPORT%" >nul 2>nul
  exit /b 1
)

for %%Z in ("%SELECTED%") do set "ZIPNAME=%%~nxZ"
move /Y "%SELECTED%" "%APPLIED%\%ZIPNAME%" >nul 2>nul
(
  echo APPLY_EXIT_CODE=0
  echo APPLIED_PATCH=%APPLIED%\%ZIPNAME%
  echo RESULT=PASS_PATCH_APPLIED_RESTART_DASH_REQUIRED
)>>"%REPORT%"
copy /Y "%REPORT%" "%DESKTOP_REPORT%" >nul 2>nul
exit /b 0
