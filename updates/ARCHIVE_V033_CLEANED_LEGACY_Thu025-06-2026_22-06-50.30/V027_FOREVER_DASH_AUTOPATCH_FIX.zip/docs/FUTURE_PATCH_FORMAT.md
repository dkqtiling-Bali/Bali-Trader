# Future Bali Auto Patch ZIP Format

Every functional patch ZIP must contain a root-level or nested file named:

`BALI_PATCH_APPLY.bat`

The apply BAT must:
- Use no Python.
- Write a visible report to `shared_data\reports`.
- Write a marker to `tools` when relevant.
- Exit with code `0` only if the patch was applied.
- Exit non-zero if it failed.

The detector will:
- Select the newest `.zip` in the outer `updates` folder.
- Move extra ZIPs to `updates\QUARANTINE`.
- Extract the selected ZIP.
- Run `BALI_PATCH_APPLY.bat`.
- Move successful ZIPs to `updates\APPLIED`.
- Move failed or invalid ZIPs to `updates\QUARANTINE`.
