# V027 Forever Dash Auto-Patch Fix

Purpose: repair the Bali Forever desktop icon so it runs the outer `updates` folder detector before starting the dashboard.

Target watch folder:

`C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\updates`

Safety:
- Live orders stay OFF.
- Champion lock stays LOCKED.
- No API keys are added.
- No private exchange endpoints are used.
- Python is not used.
- The old Update Dock validator is not used.

How future patches should work:
1. Put one patch ZIP in the outer `updates` folder.
2. The ZIP must contain `BALI_PATCH_APPLY.bat`.
3. Click `Bali Forever Mission Control`.
4. The detector extracts the ZIP, runs `BALI_PATCH_APPLY.bat`, moves the ZIP to `updates\APPLIED`, starts/reopens the dashboard, and opens the report.

Install:
1. Close Bali.
2. Unzip this package.
3. Double-click `FIX_BALI_FOREVER_DASH_AUTO_PATCH_NOW.bat`.
4. Use only the desktop shortcut `Bali Forever Mission Control`.

Test:
1. Copy `V027_TEST_PATCH_DROP_IN_UPDATES.zip` into the outer `updates` folder.
2. Double-click `Bali Forever Mission Control`.
3. Check `shared_data\reports\BALI_DASH_UPDATES_AUTO_DETECTOR_REPORT.txt`.
