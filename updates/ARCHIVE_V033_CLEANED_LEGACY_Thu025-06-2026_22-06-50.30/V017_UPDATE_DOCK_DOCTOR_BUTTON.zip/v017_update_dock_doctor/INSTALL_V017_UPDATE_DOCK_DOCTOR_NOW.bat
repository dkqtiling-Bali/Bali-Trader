@echo off
setlocal
cd /d "%~dp0"
echo Bali V017 Update Dock Doctor installer
echo Safety: live orders OFF unchanged; no API keys; no internet fetching.
python install_v017_update_dock_doctor.py
if errorlevel 1 (
  echo.
  echo Python install failed. Try: py install_v017_update_dock_doctor.py
  py install_v017_update_dock_doctor.py
)
echo.
echo Running first diagnosis from this folder...
python update_dock_doctor_v017.py
if errorlevel 1 (
  echo.
  echo Doctor returned warnings/failures. That is useful. Check the generated report.
)
echo.
echo Done. Paste BALI_UPDATE_DOCK_DOCTOR_REPORT.txt back into ChatGPT if the dashboard still will not apply patches.
pause
