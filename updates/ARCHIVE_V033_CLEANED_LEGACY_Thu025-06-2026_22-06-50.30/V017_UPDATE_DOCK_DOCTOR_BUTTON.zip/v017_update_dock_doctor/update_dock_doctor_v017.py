#!/usr/bin/env python3
"""
Bali Rocket Crypto Command - V017 Update Dock Doctor
Safe local diagnosis only. No live orders. No API keys. No internet fetching.

Purpose:
- Diagnose why a selected/uploaded patch ZIP is not becoming "next patch waiting"
- Inspect UPDATE_INBOX, patch ZIP manifests/layout, local logs/reports, and write a concise answer
- Can be called by a dashboard button or run directly from Windows cmd/PowerShell
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import platform
import re
import sys
import traceback
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "V017_UPDATE_DOCK_DOCTOR"
SAFETY = {
    "live_orders": "OFF_UNCHANGED",
    "api_keys": "NOT_READ_NOT_REQUIRED",
    "exchange_private_endpoints": "NOT_USED",
    "internet_fetching": "DISABLED",
    "champion_lock": "NOT_MODIFIED",
    "risk_police": "NOT_MODIFIED",
    "scoring": "NO_FAKE_OFFLINE_DEMO_SCORING",
}
MANIFEST_NAMES = {
    "PATCH_MANIFEST.json",
    "patch_manifest.json",
    "BALI_PATCH_MANIFEST.json",
    "manifest.json",
    "bali_patch_manifest.json",
}
SUSPICIOUS_ZIP_PATTERNS = (
    "__MACOSX/",
    ".pytest_cache/",
    ".git/",
    "node_modules/",
    "venv/",
    ".venv/",
    "dist/",
    "build/",
)
DANGEROUS_NAME_RE = re.compile(r"(^|/)(\.\.|~|CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])($|/|\.)", re.I)
LOG_KEYWORDS_RE = re.compile(
    r"(traceback|exception|error|failed|fail|reject|invalid|manifest|zip|upload|restart|patch|permission|denied|not found)",
    re.I,
)
VERSION_RE = re.compile(r"V\d{3}[A-Z]?(?:_[A-Z0-9]+)*")


@dataclass
class Finding:
    severity: str  # PASS/WARN/FAIL/INFO
    check: str
    detail: str
    fix: str = ""

    def to_line(self) -> str:
        base = f"[{self.severity}] {self.check}: {self.detail}"
        if self.fix:
            return base + f" | Fix: {self.fix}"
        return base


def now_utc() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_read_text(path: Path, limit_bytes: int = 300_000) -> str:
    try:
        data = path.read_bytes()[:limit_bytes]
        return data.decode("utf-8", errors="replace")
    except Exception as exc:
        return f"<unreadable: {exc}>"


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def candidate_roots(start: Path) -> List[Path]:
    start = start.resolve()
    roots: List[Path] = []
    for p in [start] + list(start.parents):
        roots.append(p)
    # Include common sibling/parent hints if launched from a rescue folder inside root.
    for p in list(roots):
        for child in (p / "bali_rocket_crypto_command_v011b", p / "app", p / "server"):
            if child.exists():
                roots.append(child)
    # De-duplicate, preserve order.
    out: List[Path] = []
    seen = set()
    for p in roots:
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def score_root(path: Path) -> int:
    score = 0
    hints = [
        "UPDATE_INBOX",
        "shared_data",
        "reports",
        "app.py",
        "server.py",
        "main.py",
        "dashboard.py",
        "templates",
        "static",
    ]
    for h in hints:
        if (path / h).exists():
            score += 10
    if "bali" in path.name.lower():
        score += 5
    return score


def detect_root(explicit_root: Optional[str]) -> Path:
    if explicit_root:
        return Path(explicit_root).expanduser().resolve()
    starts = [Path.cwd(), Path(__file__).resolve().parent]
    best: Optional[Tuple[int, Path]] = None
    for start in starts:
        for root in candidate_roots(start):
            s = score_root(root)
            if best is None or s > best[0]:
                best = (s, root)
    return best[1] if best and best[0] > 0 else Path.cwd().resolve()


def find_update_inbox(root: Path) -> Path:
    direct = root / "UPDATE_INBOX"
    if direct.exists():
        return direct
    # Search shallow only to avoid slow scans.
    for depth_root in [root, root.parent]:
        try:
            for p in depth_root.glob("**/UPDATE_INBOX"):
                if p.is_dir():
                    return p.resolve()
        except Exception:
            pass
    return direct


def find_reports_dir(root: Path) -> Path:
    for p in [root / "shared_data" / "reports", root / "reports", root / "shared_data"]:
        if p.exists():
            return p
    return root / "shared_data" / "reports"


def is_writable_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        test = path / f".write_test_{os.getpid()}.tmp"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def list_recent_files(root: Path, patterns: Iterable[str], max_files: int = 80) -> List[Path]:
    files: List[Path] = []
    for pat in patterns:
        try:
            files.extend([p for p in root.glob(pat) if p.is_file()])
        except Exception:
            continue
    files = sorted(set(files), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return files[:max_files]


def find_zip_candidates(root: Path, inbox: Path, explicit_zip: Optional[str]) -> List[Path]:
    candidates: List[Path] = []
    if explicit_zip:
        candidates.append(Path(explicit_zip).expanduser().resolve())
    for base in [inbox, Path(__file__).resolve().parent, root, Path.cwd()]:
        if base.exists():
            candidates.extend(list(base.glob("*.zip")))
    # Deduplicate and sort explicit first then newest.
    dedup: List[Path] = []
    seen = set()
    for p in candidates:
        key = str(p.resolve()).lower()
        if key not in seen:
            seen.add(key)
            dedup.append(p.resolve())
    return sorted(dedup, key=lambda p: (0 if explicit_zip and p == Path(explicit_zip).expanduser().resolve() else 1, -(p.stat().st_mtime if p.exists() else 0)))[:20]


def inspect_zip(path: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "path": str(path),
        "exists": path.exists(),
        "readable": False,
        "size_bytes": None,
        "sha256": None,
        "entry_count": 0,
        "top_level_entries": [],
        "manifest_entries": [],
        "manifest_json": [],
        "dangerous_entries": [],
        "suspicious_entries": [],
        "nested_single_folder": False,
        "python_files": [],
        "bat_files": [],
        "errors": [],
    }
    if not path.exists():
        info["errors"].append("zip path does not exist")
        return info
    try:
        info["size_bytes"] = path.stat().st_size
        info["sha256"] = sha256_file(path)
        with zipfile.ZipFile(path, "r") as zf:
            bad = zf.testzip()
            if bad:
                info["errors"].append(f"zip CRC/test failed at {bad}")
            names = zf.namelist()
            info["readable"] = True
            info["entry_count"] = len(names)
            tops = []
            for n in names:
                n2 = n.replace("\\", "/")
                if not n2 or n2.endswith("/"):
                    continue
                top = n2.split("/", 1)[0]
                if top not in tops:
                    tops.append(top)
                if n2.split("/")[-1] in MANIFEST_NAMES:
                    info["manifest_entries"].append(n2)
                    try:
                        raw = zf.read(n).decode("utf-8", errors="replace")
                        parsed = json.loads(raw)
                        info["manifest_json"].append({"entry": n2, "json": parsed})
                    except Exception as exc:
                        info["errors"].append(f"manifest not valid json: {n2}: {exc}")
                if n2.startswith("/") or DANGEROUS_NAME_RE.search(n2):
                    info["dangerous_entries"].append(n2)
                if any(n2.startswith(prefix) or f"/{prefix}" in n2 for prefix in SUSPICIOUS_ZIP_PATTERNS):
                    info["suspicious_entries"].append(n2)
                if n2.lower().endswith(".py"):
                    info["python_files"].append(n2)
                if n2.lower().endswith((".bat", ".cmd", ".ps1")):
                    info["bat_files"].append(n2)
            info["top_level_entries"] = tops[:60]
            file_tops = [t for t in tops if not t.endswith("/")]
            if len(file_tops) == 1 and any("/" in n.replace("\\", "/") for n in names):
                info["nested_single_folder"] = True
    except zipfile.BadZipFile:
        info["errors"].append("not a valid zip file")
    except Exception as exc:
        info["errors"].append(f"zip inspection error: {exc}")
    return info


def analyze_zip(zip_info: Dict[str, Any]) -> List[Finding]:
    f: List[Finding] = []
    path = zip_info["path"]
    if not zip_info["exists"]:
        f.append(Finding("FAIL", "Patch ZIP exists", f"Missing: {path}", "Download/copy the ZIP into UPDATE_INBOX or select it in the dashboard."))
        return f
    if not zip_info["readable"]:
        f.append(Finding("FAIL", "Patch ZIP readable", f"Unreadable or invalid ZIP: {path}", "Re-download the ZIP; do not unzip/re-zip with Windows compressed folders if it corrupts."))
        return f
    if zip_info.get("errors"):
        f.append(Finding("FAIL", "Patch ZIP integrity", "; ".join(zip_info["errors"]), "Use a freshly built ZIP and rerun this doctor."))
    else:
        f.append(Finding("PASS", "Patch ZIP integrity", f"Readable ZIP, {zip_info['entry_count']} entries, sha256={str(zip_info['sha256'])[:16]}..."))
    size = zip_info.get("size_bytes") or 0
    if size <= 0:
        f.append(Finding("FAIL", "Patch ZIP size", "ZIP is empty", "Re-download the ZIP."))
    elif size < 1000:
        f.append(Finding("WARN", "Patch ZIP size", f"Very small ZIP ({size} bytes)", "Confirm this is not an HTML download page or partial file."))
    else:
        f.append(Finding("PASS", "Patch ZIP size", f"{size} bytes"))
    if not zip_info["manifest_entries"]:
        f.append(Finding("FAIL", "Patch manifest", "No recognized manifest file found", "Add PATCH_MANIFEST.json at ZIP root."))
    else:
        f.append(Finding("PASS", "Patch manifest", "Found: " + ", ".join(zip_info["manifest_entries"][:6])))
    if zip_info["nested_single_folder"]:
        f.append(Finding("WARN", "ZIP layout", "All files appear nested under one top-level folder", "If Bali expects root-level manifest, repackage with manifest at ZIP root."))
    else:
        f.append(Finding("PASS", "ZIP layout", "Files are available at ZIP root or multiple expected top-level entries."))
    if zip_info["dangerous_entries"]:
        f.append(Finding("FAIL", "ZIP path safety", "Dangerous path entries found: " + ", ".join(zip_info["dangerous_entries"][:10]), "Reject this ZIP and rebuild without absolute/parent paths."))
    else:
        f.append(Finding("PASS", "ZIP path safety", "No path traversal or reserved-name entries found."))
    if zip_info["suspicious_entries"]:
        f.append(Finding("WARN", "ZIP junk/cache", "Suspicious/cache entries found", "Remove cache/build/test junk before uploading."))
    else:
        f.append(Finding("PASS", "ZIP junk/cache", "No common cache/build junk detected."))
    # Manifest content checks.
    manifests = zip_info.get("manifest_json") or []
    if manifests:
        merged = manifests[0].get("json", {})
        patch_id = merged.get("patch_id") or merged.get("version") or merged.get("name")
        if patch_id:
            f.append(Finding("PASS", "Manifest patch id", str(patch_id)))
        else:
            f.append(Finding("WARN", "Manifest patch id", "Manifest parsed, but no patch_id/version/name field found", "Add patch_id and version fields."))
        safety = json.dumps(merged, sort_keys=True).lower()
        if any(term in safety for term in ["live_orders", "champion", "api", "risk"]):
            f.append(Finding("INFO", "Manifest safety fields", "Manifest includes safety-related fields; review expected lock values."))
    return f


def collect_log_hits(root: Path, inbox: Path, reports_dir: Path, limit_files: int = 60, limit_hits: int = 80) -> List[Dict[str, Any]]:
    scan_roots = []
    for p in [root, root / "logs", root / "shared_data", reports_dir, inbox]:
        if p.exists() and p not in scan_roots:
            scan_roots.append(p)
    files: List[Path] = []
    for base in scan_roots:
        for pat in ["*.log", "*.txt", "*.md", "*.json", "**/*.log", "**/*doctor*.txt", "**/*status*.txt", "**/*patch*.txt", "**/*update*.log", "**/*error*.log"]:
            try:
                files.extend([p for p in base.glob(pat) if p.is_file() and p.stat().st_size < 2_000_000])
            except Exception:
                pass
    files = sorted(set(files), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)[:limit_files]
    hits: List[Dict[str, Any]] = []
    for p in files:
        text = safe_read_text(p, limit_bytes=250_000)
        lines = text.splitlines()
        for idx, line in enumerate(lines, 1):
            if LOG_KEYWORDS_RE.search(line):
                hits.append({
                    "file": str(p),
                    "line": idx,
                    "text": line.strip()[:500],
                    "mtime_utc": _dt.datetime.fromtimestamp(p.stat().st_mtime, _dt.timezone.utc).isoformat(timespec="seconds"),
                })
                if len(hits) >= limit_hits:
                    return hits
    return hits


def discover_versions(root: Path, reports_dir: Path) -> List[Dict[str, str]]:
    files = list_recent_files(root, ["*.txt", "*.md", "*.json", "shared_data/**/*.txt", "shared_data/**/*.md", "shared_data/**/*.json", "reports/**/*.txt", "reports/**/*.md"], max_files=80)
    out: List[Dict[str, str]] = []
    seen = set()
    for p in files:
        text = safe_read_text(p, limit_bytes=80_000)
        for m in VERSION_RE.finditer(text):
            v = m.group(0)
            key = (str(p), v)
            if key not in seen:
                seen.add(key)
                out.append({"version": v, "file": str(p)})
        if len(out) >= 30:
            break
    return out


def diagnose(root: Path, zip_path: Optional[str]) -> Dict[str, Any]:
    findings: List[Finding] = []
    inbox = find_update_inbox(root)
    reports_dir = find_reports_dir(root)

    findings.append(Finding("INFO", "Doctor version", VERSION))
    findings.append(Finding("INFO", "Safety", json.dumps(SAFETY, sort_keys=True)))
    findings.append(Finding("INFO", "Detected Bali root", str(root)))

    if inbox.exists():
        findings.append(Finding("PASS", "UPDATE_INBOX exists", str(inbox)))
    else:
        findings.append(Finding("FAIL", "UPDATE_INBOX exists", f"Missing expected folder: {inbox}", "Create UPDATE_INBOX or run this from the real Bali app root."))
    if is_writable_dir(inbox):
        findings.append(Finding("PASS", "UPDATE_INBOX writable", str(inbox)))
    else:
        findings.append(Finding("FAIL", "UPDATE_INBOX writable", f"Cannot write to {inbox}", "Run Bali/Doctor as a user with folder write permission; avoid protected folders."))

    zips = find_zip_candidates(root, inbox, zip_path)
    zip_infos = [inspect_zip(p) for p in zips]
    if not zips:
        findings.append(Finding("FAIL", "Patch ZIP discovery", "No ZIP found in UPDATE_INBOX, doctor folder, app root, or explicit --zip path", "Copy the patch ZIP into UPDATE_INBOX, then run the doctor again."))
    else:
        findings.append(Finding("PASS", "Patch ZIP discovery", f"Found {len(zips)} candidate ZIP(s); inspecting newest/explicit first."))
        findings.extend(analyze_zip(zip_infos[0]))

    # The likely user-specific symptom.
    if zips and not any(str(p).lower().startswith(str(inbox).lower()) for p in zips):
        findings.append(Finding("WARN", "Patch queue location", "ZIP was found, but not inside UPDATE_INBOX", "Copy the ZIP into UPDATE_INBOX, then click Apply ZIP Already in Updates."))
    elif zips:
        findings.append(Finding("PASS", "Patch queue location", "At least one ZIP candidate is inside UPDATE_INBOX or explicit path was provided."))

    log_hits = collect_log_hits(root, inbox, reports_dir)
    if log_hits:
        findings.append(Finding("WARN", "Recent local error clues", f"Found {len(log_hits)} log/report lines mentioning errors, rejects, upload, manifest, or patch."))
    else:
        findings.append(Finding("INFO", "Recent local error clues", "No obvious local error lines found in shallow scan."))

    versions = discover_versions(root, reports_dir)
    installed_versions = [v for v in versions if "V015A" in v["version"] or "V016" in v["version"] or "V017" in v["version"]]
    if installed_versions:
        findings.append(Finding("INFO", "Version clues", ", ".join(sorted({v['version'] for v in installed_versions})[:10])))
    else:
        findings.append(Finding("INFO", "Version clues", "No V015/V016/V017 version clues found in scanned files."))

    # Root cause heuristic.
    root_cause = "UNKNOWN_NEEDS_FULL_ERROR_LOG"
    action = "Open the Doctor details and paste the generated BALI_UPDATE_DOCK_DOCTOR_REPORT.txt back to ChatGPT."
    if zips:
        primary = zip_infos[0]
        if not primary.get("exists") or not primary.get("readable"):
            root_cause = "PATCH_ZIP_NOT_READABLE_OR_MISSING"
            action = "Re-download the patch ZIP, copy it into UPDATE_INBOX, and run this doctor again."
        elif not primary.get("manifest_entries"):
            root_cause = "PATCH_MANIFEST_NOT_DETECTED"
            action = "Rebuild the patch ZIP with PATCH_MANIFEST.json at the ZIP root."
        elif primary.get("nested_single_folder"):
            root_cause = "PATCH_ZIP_MAY_BE_NESTED_WHILE_UPDATE_DOCK_EXPECTS_ROOT_MANIFEST"
            action = "Use a root-level ZIP layout or update the Update Dock to search inside one top-level folder."
        elif not any(str(Path(zi["path"])).lower().startswith(str(inbox).lower()) for zi in zip_infos if zi.get("exists")):
            root_cause = "PATCH_SELECTED_BUT_NOT_COPIED_TO_UPDATE_INBOX"
            action = "Copy the selected ZIP into UPDATE_INBOX or fix the dashboard upload route that writes there."
        elif log_hits:
            root_cause = "LOCAL_UPDATE_DOCK_REJECT_OR_SERVER_ERROR_SEEN_IN_LOGS"
            action = "Read the newest log hits in this report; fix the first FAIL/exception around upload/apply."
        else:
            root_cause = "PATCH_PRESENT_AND_VALID_LOOKING_BUT_AUTOPILOT_NOT_CONSUMING"
            action = "Check autopilot watcher loop, one-patch-per-restart lock, and restart trigger; use Apply ZIP Already in Updates."

    fail_count = sum(1 for x in findings if x.severity == "FAIL")
    warn_count = sum(1 for x in findings if x.severity == "WARN")
    status = "PASS" if fail_count == 0 and warn_count == 0 else "WARN" if fail_count == 0 else "FAIL"

    return {
        "version": VERSION,
        "generated_utc": now_utc(),
        "status": status,
        "root_cause_guess": root_cause,
        "recommended_next_action": action,
        "safety": SAFETY,
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "cwd": str(Path.cwd()),
            "script": str(Path(__file__).resolve()),
            "bali_root": str(root),
            "update_inbox": str(inbox),
            "reports_dir": str(reports_dir),
        },
        "findings": [asdict(x) for x in findings],
        "zip_candidates": zip_infos,
        "recent_log_hits": log_hits,
        "version_clues": versions[:30],
    }


def render_markdown(report: Dict[str, Any]) -> str:
    lines = []
    lines.append(f"# Bali Update Dock Doctor Report - {report['version']}")
    lines.append("")
    lines.append(f"Generated UTC: {report['generated_utc']}")
    lines.append(f"Status: **{report['status']}**")
    lines.append(f"Root cause guess: **{report['root_cause_guess']}**")
    lines.append(f"Recommended next action: **{report['recommended_next_action']}**")
    lines.append("")
    lines.append("## Safety")
    for k, v in report["safety"].items():
        lines.append(f"- {k}: {v}")
    lines.append("")
    lines.append("## Environment")
    for k, v in report["environment"].items():
        lines.append(f"- {k}: `{v}`")
    lines.append("")
    lines.append("## Findings")
    for f in report["findings"]:
        fix = f" Fix: {f['fix']}" if f.get("fix") else ""
        lines.append(f"- **{f['severity']}** {f['check']}: {f['detail']}{fix}")
    lines.append("")
    lines.append("## ZIP Candidates")
    if not report["zip_candidates"]:
        lines.append("No ZIP candidates found.")
    for z in report["zip_candidates"]:
        lines.append(f"### {z.get('path')}")
        lines.append(f"- exists: {z.get('exists')}")
        lines.append(f"- readable: {z.get('readable')}")
        lines.append(f"- size_bytes: {z.get('size_bytes')}")
        lines.append(f"- sha256: {z.get('sha256')}")
        lines.append(f"- entries: {z.get('entry_count')}")
        lines.append(f"- manifests: {', '.join(z.get('manifest_entries') or []) or 'NONE'}")
        lines.append(f"- nested_single_folder: {z.get('nested_single_folder')}")
        if z.get("errors"):
            lines.append(f"- errors: {'; '.join(z.get('errors'))}")
    lines.append("")
    lines.append("## Recent Local Error Clues")
    if not report["recent_log_hits"]:
        lines.append("No obvious local error clues found in shallow scan.")
    for h in report["recent_log_hits"][:50]:
        lines.append(f"- `{h['file']}` line {h['line']}: {h['text']}")
    lines.append("")
    lines.append("## Version Clues")
    if not report["version_clues"]:
        lines.append("No version clues found.")
    for v in report["version_clues"][:30]:
        lines.append(f"- {v['version']} in `{v['file']}`")
    lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Bali V017 Update Dock Doctor")
    parser.add_argument("--root", default=None, help="Bali app root. If omitted, auto-detect from cwd/script folder.")
    parser.add_argument("--zip", dest="zip_path", default=None, help="Optional patch ZIP to inspect explicitly.")
    parser.add_argument("--out", default=None, help="Output directory for reports. Defaults to shared_data/reports if found.")
    parser.add_argument("--json", action="store_true", help="Print JSON report to stdout.")
    args = parser.parse_args(argv)

    try:
        root = detect_root(args.root)
        report = diagnose(root, args.zip_path)
        reports_dir = Path(args.out).expanduser().resolve() if args.out else find_reports_dir(root)
        reports_dir.mkdir(parents=True, exist_ok=True)
        json_path = reports_dir / "BALI_UPDATE_DOCK_DOCTOR_REPORT.json"
        txt_path = reports_dir / "BALI_UPDATE_DOCK_DOCTOR_REPORT.txt"
        md_path = reports_dir / "BALI_UPDATE_DOCK_DOCTOR_REPORT.md"
        write_text(json_path, json.dumps(report, indent=2, sort_keys=True))
        md = render_markdown(report)
        write_text(md_path, md)
        write_text(txt_path, md)
        if args.json:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print(f"Bali Update Dock Doctor: {report['status']}")
            print(f"Root cause guess: {report['root_cause_guess']}")
            print(f"Recommended next action: {report['recommended_next_action']}")
            print(f"Report: {txt_path}")
            print("Safety: live orders OFF unchanged; no API keys read; no internet fetching.")
        return 0 if report["status"] == "PASS" else 2 if report["status"] == "WARN" else 3
    except Exception:
        print("Bali Update Dock Doctor crashed:")
        print(traceback.format_exc())
        return 10


if __name__ == "__main__":
    raise SystemExit(main())
