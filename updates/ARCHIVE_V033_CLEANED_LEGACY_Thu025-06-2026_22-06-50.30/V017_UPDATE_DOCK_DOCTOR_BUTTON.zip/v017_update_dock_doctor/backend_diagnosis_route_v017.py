"""
Optional Flask integration for Bali V017 Update Dock Doctor.
Paste/register this only if your dashboard uses Flask.
It does NOT enable live trading or API keys.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

try:
    from flask import Blueprint, jsonify, request
except Exception:  # Allows static linting without Flask installed.
    Blueprint = None

if Blueprint is not None:
    update_dock_doctor_bp = Blueprint("update_dock_doctor_v017", __name__)

    @update_dock_doctor_bp.route("/api/update-dock/doctor", methods=["GET", "POST"])
    def run_update_dock_doctor():
        root = Path.cwd()
        script = root / "tools" / "update_dock_doctor_v017.py"
        if not script.exists():
            script = root / "update_dock_doctor_v017.py"
        if not script.exists():
            return jsonify({
                "status": "FAIL",
                "error": "update_dock_doctor_v017.py not found in app root or tools folder",
                "safety": "live_orders_off_unchanged_no_api_keys_no_internet_fetching",
            }), 404

        zip_path = None
        try:
            data = request.get_json(silent=True) or {}
            zip_path = data.get("zip_path")
        except Exception:
            zip_path = None

        cmd = [sys.executable, str(script), "--root", str(root), "--json"]
        if zip_path:
            cmd += ["--zip", zip_path]
        proc = subprocess.run(cmd, cwd=str(root), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=45)
        if proc.returncode not in (0, 2, 3):
            return jsonify({
                "status": "FAIL",
                "error": "doctor execution failed",
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
                "safety": "live_orders_off_unchanged_no_api_keys_no_internet_fetching",
            }), 500
        try:
            return jsonify(json.loads(proc.stdout))
        except Exception:
            return jsonify({
                "status": "WARN",
                "root_cause_guess": "DOCTOR_RAN_BUT_JSON_PARSE_FAILED",
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
                "safety": "live_orders_off_unchanged_no_api_keys_no_internet_fetching",
            })

# In your app startup, add something like:
# from backend_diagnosis_route_v017 import update_dock_doctor_bp
# app.register_blueprint(update_dock_doctor_bp)
