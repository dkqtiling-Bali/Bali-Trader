# V017 Update Dock Doctor + Diagnosis Button

This is a safe local diagnosis kit for repeated Bali patch upload/apply failures.

It does **not** enable live orders, read API keys, use private exchange endpoints, fetch the internet, unlock Champion Council, or fake any scoring.

## Why this exists

The dashboard showed the patch ZIP selected, but still reported:

- Installed: `V015A_BACKTEST_WALK_FORWARD_GATE`
- Next patch: `none waiting`

That means the file picker succeeded, but the update/apply path did not copy, validate, queue, or consume the patch.

## What V017 checks

- Is `UPDATE_INBOX` present?
- Is `UPDATE_INBOX` writable?
- Is a patch ZIP actually in the queue?
- Is the ZIP readable and non-corrupt?
- Does the ZIP have a recognized manifest?
- Is the manifest at the ZIP root or nested one folder down?
- Are there dangerous paths or cache/build junk entries?
- Do local logs/reports contain upload/apply/manifest/restart errors?
- Are version clues still stuck on V015A?

## Fast use

1. Unzip this folder into the Bali app root or `UPDATE_INBOX`.
2. Double-click `INSTALL_V017_UPDATE_DOCK_DOCTOR_NOW.bat`.
3. Open the generated `BALI_UPDATE_DOCK_DOCTOR_REPORT.txt`.
4. Paste that report into ChatGPT.

## Manual command

From the Bali app root:

```bat
python tools\update_dock_doctor_v017.py --root .
```

To inspect a specific ZIP:

```bat
python tools\update_dock_doctor_v017.py --root . --zip C:\path\to\V016_FIXED_UPLOAD_READY_BALI_PATCH.zip
```

## Dashboard button integration

If Bali uses Flask:

1. Copy `tools/backend_diagnosis_route_v017.py` into the app.
2. Register the blueprint:

```python
from tools.backend_diagnosis_route_v017 import update_dock_doctor_bp
app.register_blueprint(update_dock_doctor_bp)
```

3. Paste `tools/dashboard_diagnosis_button_snippet_v017.html` into the Update Dock page.

The button calls `/api/update-dock/doctor` and prints a copyable diagnosis.
