#!/usr/bin/env python3
"""Install V017 Update Dock Doctor files into a Bali app folder safely."""
from __future__ import annotations
import datetime as dt
import json
import shutil
import sys
from pathlib import Path

VERSION = "V017_UPDATE_DOCK_DOCTOR"
FILES = [
    "update_dock_doctor_v017.py",
    "backend_diagnosis_route_v017.py",
    "dashboard_diagnosis_button_snippet_v017.html",
]

def detect_root() -> Path:
    here = Path(__file__).resolve().parent
    for p in [Path.cwd(), here] + list(here.parents):
        if (p / "UPDATE_INBOX").exists() or (p / "shared_data").exists() or "bali" in p.name.lower():
            return p.resolve()
    return Path.cwd().resolve()

def main() -> int:
    src = Path(__file__).resolve().parent
    root = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else detect_root()
    tools = root / "tools"
    reports = root / "shared_data" / "reports"
    tools.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)
    copied = []
    for name in FILES:
        sp = src / name
        if sp.exists():
            dest = tools / name
            shutil.copy2(sp, dest)
            copied.append(str(dest))
    marker = {
        "version": VERSION,
        "installed_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "bali_root": str(root),
        "copied": copied,
        "safety": {
            "live_orders": "OFF_UNCHANGED",
            "api_keys": "NOT_READ_NOT_REQUIRED",
            "internet_fetching": "DISABLED",
            "champion_lock": "NOT_MODIFIED",
        },
        "manual_dashboard_step": "Register tools/backend_diagnosis_route_v017.py blueprint and paste tools/dashboard_diagnosis_button_snippet_v017.html into Update Dock page if automatic UI patching is not available.",
    }
    (reports / "V017_UPDATE_DOCK_DOCTOR_INSTALLED.json").write_text(json.dumps(marker, indent=2), encoding="utf-8")
    (reports / "V017_UPDATE_DOCK_DOCTOR_INSTALLED.txt").write_text(
        "V017 Update Dock Doctor installed.\n"
        f"Root: {root}\n"
        "Run: python tools\\update_dock_doctor_v017.py --root .\n"
        "Optional dashboard: register backend route and paste button snippet.\n"
        "Safety: live orders OFF unchanged; no API keys; no internet fetching.\n",
        encoding="utf-8",
    )
    print("V017 Update Dock Doctor installed")
    print(f"Root: {root}")
    print("Run now with: python tools\\update_dock_doctor_v017.py --root .")
    print(f"Install marker: {reports / 'V017_UPDATE_DOCK_DOCTOR_INSTALLED.txt'}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
