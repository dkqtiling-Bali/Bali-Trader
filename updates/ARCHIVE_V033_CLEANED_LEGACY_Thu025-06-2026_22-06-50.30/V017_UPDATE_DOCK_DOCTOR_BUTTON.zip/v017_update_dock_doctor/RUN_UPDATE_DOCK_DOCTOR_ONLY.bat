@echo off
setlocal
cd /d "%~dp0"
echo Running Bali V017 Update Dock Doctor...
python update_dock_doctor_v017.py
if errorlevel 1 (
  py update_dock_doctor_v017.py
)
echo.
echo Look for BALI_UPDATE_DOCK_DOCTOR_REPORT.txt in shared_data\reports or this folder's report location.
pause
