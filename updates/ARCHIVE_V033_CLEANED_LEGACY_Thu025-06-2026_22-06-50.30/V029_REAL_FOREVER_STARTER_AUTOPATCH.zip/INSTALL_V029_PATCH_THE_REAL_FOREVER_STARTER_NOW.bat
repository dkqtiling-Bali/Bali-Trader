@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem ==========================================================
rem  BALI V029 - PATCH THE REAL FOREVER STARTER
rem  No Python. No Update Dock validator. No live trading.
rem ==========================================================

set "ROOT=C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
set "APPROOT=%ROOT%\bali_rocket_crypto_command_v011b"
set "STARTER=%ROOT%\BALI_THEMED_FOREVER_STARTER.bat"
set "ORIGINAL=%ROOT%\BALI_THEMED_FOREVER_STARTER_ORIGINAL_V029.bat"
set "TOOLS=%APPROOT%\tools\BALI_FOREVER_STARTER_AUTOPATCH"
set "REPORTS=%APPROOT%\shared_data\reports"
set "DESKTOP=%USERPROFILE%\Desktop"
set "INSTALL_REPORT=%DESKTOP%\BALI_V029_FOREVER_STARTER_AUTOPATCH_INSTALL_REPORT.txt"

if not exist "%ROOT%" (
  echo RESULT=FAIL_ROOT_NOT_FOUND> "%INSTALL_REPORT%"
  echo ROOT=%ROOT%>> "%INSTALL_REPORT%"
  start "" notepad "%INSTALL_REPORT%"
  exit /b 1
)

if not exist "%APPROOT%" mkdir "%APPROOT%" >nul 2>nul
if not exist "%TOOLS%" mkdir "%TOOLS%" >nul 2>nul
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%ROOT%\updates" mkdir "%ROOT%\updates" >nul 2>nul
if not exist "%ROOT%\updates\APPLIED" mkdir "%ROOT%\updates\APPLIED" >nul 2>nul
if not exist "%ROOT%\updates\QUARANTINE" mkdir "%ROOT%\updates\QUARANTINE" >nul 2>nul

if not exist "%STARTER%" (
  echo @echo off> "%STARTER%"
  echo echo Bali original starter was missing. This placeholder opens dashboard only.>> "%STARTER%"
  echo start "" http://127.0.0.1:9061>> "%STARTER%"
)

rem Preserve the actual forever starter once. Do not overwrite it on repeated installs.
if not exist "%ORIGINAL%" (
  copy /Y "%STARTER%" "%ORIGINAL%" >nul
)

rem Write the preflight autopatch engine.
> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo @echo off
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo setlocal EnableExtensions EnableDelayedExpansion
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo rem V029_FOREVER_STARTER_AUTOPATCH_PREFLIGHT
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "ROOT=C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "APPROOT=%%ROOT%%\bali_rocket_crypto_command_v011b"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "UPDATES=%%ROOT%%\updates"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "APPLIED=%%UPDATES%%\APPLIED"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "QUARANTINE=%%UPDATES%%\QUARANTINE"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "REPORTS=%%APPROOT%%\shared_data\reports"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "DESKTOP=%%USERPROFILE%%\Desktop"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "REPORT=%%REPORTS%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "PROOF=%%REPORTS%%\BALI_TRUE_AUTOPATCH_PRELAUNCH_PROOF.txt"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if not exist "%%REPORTS%%" mkdir "%%REPORTS%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if not exist "%%UPDATES%%" mkdir "%%UPDATES%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if not exist "%%APPLIED%%" mkdir "%%APPLIED%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if not exist "%%QUARANTINE%%" mkdir "%%QUARANTINE%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^> "%%PROOF%%" echo BALI TRUE AUTOPATCH PRELAUNCH PROOF
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%PROOF%%" echo Generated: %%DATE%% %%TIME%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%PROOF%%" echo VERSION=V029_FOREVER_STARTER_AUTOPATCH_PREFLIGHT
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%PROOF%%" echo RESULT=PRELAUNCH_PROOF_WRITTEN_BEFORE_BALI_START
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%PROOF%%" echo WATCH_FOLDER=%%UPDATES%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%PROOF%%" echo SAFETY=LIVE_ORDERS_OFF ^^^| CHAMPION_LOCK_LOCKED ^^^| NO_API_KEYS
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "COUNT=0"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo for /f %%%%C in ^('dir /b /a-d "%%UPDATES%%\*.zip" 2^^^>nul ^^^| find /c /v ""'^) do set "COUNT=%%%%C"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^> "%%REPORT%%" echo BALI FOREVER AUTOPATCH PREFLIGHT REPORT
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo Generated: %%DATE%% %%TIME%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo VERSION=V029_FOREVER_STARTER_AUTOPATCH_PREFLIGHT
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo SAFETY=LIVE_ORDERS_OFF ^^^| CHAMPION_LOCK_LOCKED ^^^| NO_API_KEYS
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo PYTHON_USED=NO
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo UPDATE_DOCK_USED=NO
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo WATCH_FOLDER=%%UPDATES%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo PATCH_ZIP_COUNT=%%COUNT%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if "%%COUNT%%"=="0" ^(
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   ^>^> "%%REPORT%%" echo RESULT=PASS_NO_PATCH_WAITING_START_BALI
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   copy /Y "%%REPORT%%" "%%DESKTOP%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   exit /b 0
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^)
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "PATCH="
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo for /f "delims=" %%%%Z in ^('dir /b /a-d /o:n "%%UPDATES%%\*.zip" 2^^^>nul'^) do if not defined PATCH set "PATCH=%%%%Z"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "PATCH_PATH=%%UPDATES%%\%%PATCH%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo SELECTED_PATCH=%%PATCH%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo set "WORK=%%TEMP%%\BALI_AUTOPATCH_V029_%%RANDOM%%%%RANDOM%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo mkdir "%%WORK%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%%PATCH_PATH%%' -DestinationPath '%%WORK%%' -Force" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if errorlevel 1 ^(
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   ^>^> "%%REPORT%%" echo RESULT=FAIL_ZIP_EXTRACT_FAILED_QUARANTINED
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   move /Y "%%PATCH_PATH%%" "%%QUARANTINE%%\%%PATCH%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   copy /Y "%%REPORT%%" "%%DESKTOP%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   start "" notepad "%%REPORT%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   exit /b 1
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^)
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if not exist "%%WORK%%\AUTO_PATCH_INSTALL.bat" ^(
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   ^>^> "%%REPORT%%" echo RESULT=FAIL_NO_AUTO_PATCH_INSTALL_BAT_QUARANTINED
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   move /Y "%%PATCH_PATH%%" "%%QUARANTINE%%\%%PATCH%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   copy /Y "%%REPORT%%" "%%DESKTOP%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   start "" notepad "%%REPORT%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   exit /b 1
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^)
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo call "%%WORK%%\AUTO_PATCH_INSTALL.bat" "%%ROOT%%" "%%APPROOT%%" "%%REPORTS%%" "%%UPDATES%%" "%%PATCH%%" ^>^> "%%REPORT%%" 2^>^&1
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo if errorlevel 1 ^(
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   ^>^> "%%REPORT%%" echo RESULT=FAIL_PATCH_INSTALL_RETURNED_ERROR_QUARANTINED
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   move /Y "%%PATCH_PATH%%" "%%QUARANTINE%%\%%PATCH%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   copy /Y "%%REPORT%%" "%%DESKTOP%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   start "" notepad "%%REPORT%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo   exit /b 1
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^)
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo move /Y "%%PATCH_PATH%%" "%%APPLIED%%\%%PATCH%%" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo MOVED_TO=%%APPLIED%%\%%PATCH%%
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo ^>^> "%%REPORT%%" echo RESULT=PASS_PATCH_APPLIED_BEFORE_BALI_START
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo copy /Y "%%REPORT%%" "%%DESKTOP%%\BALI_FOREVER_AUTOPATCH_PREFLIGHT_REPORT.txt" ^>nul 2^>nul
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo start "" notepad "%%REPORT%%"
>> "%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat" echo exit /b 0

rem Write the new real forever starter wrapper in the exact root path the user specified.
> "%STARTER%" echo @echo off
>> "%STARTER%" echo setlocal EnableExtensions EnableDelayedExpansion
>> "%STARTER%" echo rem V029_FOREVER_STARTER_AUTOPATCH_WRAPPER
>> "%STARTER%" echo set "ROOT=C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
>> "%STARTER%" echo set "APPROOT=%%ROOT%%\bali_rocket_crypto_command_v011b"
>> "%STARTER%" echo set "ORIGINAL=%%ROOT%%\BALI_THEMED_FOREVER_STARTER_ORIGINAL_V029.bat"
>> "%STARTER%" echo set "PREFLIGHT=%%APPROOT%%\tools\BALI_FOREVER_STARTER_AUTOPATCH\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat"
>> "%STARTER%" echo set "LOCK=%%TEMP%%\BALI_FOREVER_STARTER_AUTOPATCH_LOCK.txt"
>> "%STARTER%" echo if exist "%%LOCK%%" ^(
>> "%STARTER%" echo   echo Bali Forever starter already running. Opening existing dashboard only.
>> "%STARTER%" echo   start "" http://127.0.0.1:9061
>> "%STARTER%" echo   exit /b 0
>> "%STARTER%" echo ^)
>> "%STARTER%" echo echo %%DATE%% %%TIME%% ^> "%%LOCK%%"
>> "%STARTER%" echo if exist "%%PREFLIGHT%%" call "%%PREFLIGHT%%"
>> "%STARTER%" echo if exist "%%ORIGINAL%%" ^(
>> "%STARTER%" echo   call "%%ORIGINAL%%"
>> "%STARTER%" echo ^) else ^(
>> "%STARTER%" echo   start "" http://127.0.0.1:9061
>> "%STARTER%" echo ^)

rem Write a lock clearer directly on Desktop.
> "%DESKTOP%\Bali Clear Forever AutoPatch Lock.bat" echo @echo off
>> "%DESKTOP%\Bali Clear Forever AutoPatch Lock.bat" echo del "%%TEMP%%\BALI_FOREVER_STARTER_AUTOPATCH_LOCK.txt" ^>nul 2^>nul
>> "%DESKTOP%\Bali Clear Forever AutoPatch Lock.bat" echo echo Bali Forever AutoPatch lock cleared.
>> "%DESKTOP%\Bali Clear Forever AutoPatch Lock.bat" echo pause

> "%INSTALL_REPORT%" echo BALI V029 REAL FOREVER STARTER AUTOPATCH INSTALL REPORT
>> "%INSTALL_REPORT%" echo Generated: %DATE% %TIME%
>> "%INSTALL_REPORT%" echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
>> "%INSTALL_REPORT%" echo VERSION=V029_PATCH_THE_REAL_FOREVER_STARTER
>> "%INSTALL_REPORT%" echo PYTHON_USED=NO
>> "%INSTALL_REPORT%" echo UPDATE_DOCK_USED=NO
>> "%INSTALL_REPORT%" echo ROOT=%ROOT%
>> "%INSTALL_REPORT%" echo STARTER_PATCHED=%STARTER%
>> "%INSTALL_REPORT%" echo ORIGINAL_BACKUP=%ORIGINAL%
>> "%INSTALL_REPORT%" echo WATCH_FOLDER=%ROOT%\updates
>> "%INSTALL_REPORT%" echo PREFLIGHT=%TOOLS%\BALI_FOREVER_AUTOPATCH_PREFLIGHT.bat
>> "%INSTALL_REPORT%" echo RESULT=PASS_V029_REAL_FOREVER_STARTER_PATCHED

copy /Y "%INSTALL_REPORT%" "%REPORTS%\BALI_V029_REAL_FOREVER_STARTER_AUTOPATCH_INSTALL_REPORT.txt" >nul 2>nul
start "" notepad "%INSTALL_REPORT%"
exit /b 0
