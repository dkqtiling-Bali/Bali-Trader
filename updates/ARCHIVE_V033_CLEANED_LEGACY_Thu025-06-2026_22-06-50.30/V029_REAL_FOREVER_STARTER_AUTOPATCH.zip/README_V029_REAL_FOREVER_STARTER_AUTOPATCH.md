# V029 Real Forever Starter AutoPatch

The real Forever starter is now the source of truth:

`C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\BALI_THEMED_FOREVER_STARTER.bat`

This installer backs that file up as:

`BALI_THEMED_FOREVER_STARTER_ORIGINAL_V029.bat`

Then it replaces the real starter with a small wrapper that:

1. Writes prelaunch proof before Bali starts.
2. Checks the outer `updates` folder for one ZIP.
3. Extracts the ZIP and runs `AUTO_PATCH_INSTALL.bat` if present.
4. Moves successful patches to `updates\APPLIED`.
5. Moves invalid patches to `updates\QUARANTINE`.
6. Starts the original Forever starter.

No Python is used. The old Update Dock validator is not used. Live trading remains off.

## Future patch format

Each future patch ZIP should include this file at its root:

`AUTO_PATCH_INSTALL.bat`

The auto patch lane calls it like this:

`AUTO_PATCH_INSTALL.bat ROOT APPROOT REPORTS UPDATES PATCH_NAME`
