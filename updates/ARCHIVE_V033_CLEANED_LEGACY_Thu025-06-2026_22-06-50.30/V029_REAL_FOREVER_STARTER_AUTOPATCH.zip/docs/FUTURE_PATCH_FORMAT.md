# Future Bali AutoPatch ZIP format

Drop ZIPs into:

`C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\updates`

Each ZIP must have:

`AUTO_PATCH_INSTALL.bat`

at ZIP root.

It must not enable live orders, add API keys, unlock Champion Council, or use private exchange endpoints.
