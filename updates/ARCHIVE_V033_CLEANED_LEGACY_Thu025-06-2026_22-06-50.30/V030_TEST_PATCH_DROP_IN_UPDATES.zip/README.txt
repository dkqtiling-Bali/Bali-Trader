V030 test patch. Place this ZIP in the outer updates folder. The V030 Forever starter wrapper should apply it before Bali starts.
