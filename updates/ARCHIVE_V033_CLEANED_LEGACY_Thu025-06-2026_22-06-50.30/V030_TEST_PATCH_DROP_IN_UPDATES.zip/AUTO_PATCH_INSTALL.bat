@echo off
setlocal
set "BASE=%~1"
set "APP=%~2"
set "UPDATES=%~3"
set "REPORTS=%~4"
if "%BASE%"=="" set "BASE=C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD"
if "%APP%"=="" set "APP=%BASE%\bali_rocket_crypto_command_v011b"
if "%REPORTS%"=="" set "REPORTS=%APP%\shared_data\reports"
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%APP%\tools" mkdir "%APP%\tools" >nul 2>nul
(
  echo BALI V030 TEST PATCH APPLIED
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo VERSION=V030_TEST_PATCH_DROP_IN_UPDATES
  echo PYTHON_USED=NO
  echo UPDATE_DOCK_USED=NO
  echo ROOT=%BASE%
  echo REPORTS=%REPORTS%
  echo RESULT=PASS_V030_TEST_PATCH_APPLIED_BY_FOREVER_STARTER_PREFLIGHT
) > "%REPORTS%\BALI_V030_TEST_PATCH_APPLIED.txt"
copy /y "%REPORTS%\BALI_V030_TEST_PATCH_APPLIED.txt" "%BASE%\BALI_V030_TEST_PATCH_APPLIED.txt" >nul 2>nul
(
  echo V030_TEST_PATCH_MARKER=PRESENT
  echo Generated=%DATE% %TIME%
) > "%APP%\tools\V030_TEST_PATCH_MARKER.txt"
exit /b 0
