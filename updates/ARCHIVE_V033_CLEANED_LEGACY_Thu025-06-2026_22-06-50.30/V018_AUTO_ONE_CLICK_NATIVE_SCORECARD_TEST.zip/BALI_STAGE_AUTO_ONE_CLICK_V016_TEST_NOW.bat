@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ==========================================================
REM  BALI V018 AUTO ONE CLICK TEST STAGER - NO PYTHON
REM ==========================================================
REM This does not install live trading. It only stages one clean
REM V016 native no-Python patch ZIP into UPDATE_INBOX so Bali's
REM existing one-click/auto updater can be tested.

set "KNOWN_ROOT=C:\Users\CB\Desktop\BALI_ROCKET_CRYPTO_COMMAND_V011B_BAD_PYTHON_HOTFIX_FULL_BUILD\bali_rocket_crypto_command_v011b"
set "PATCH_ZIP=BALI_ROCKET_CRYPTO_COMMAND_V016_NATIVE_EVIDENCE_SCORECARD_PANEL_NO_PYTHON.zip"
set "DESKTOP_REPORT=%USERPROFILE%\Desktop\BALI_V018_AUTO_ONE_CLICK_TEST_REPORT.txt"
set "ROOT="
set "HELPER=%~dp0"

cls
echo ==========================================================
echo  BALI AUTO ONE CLICK TEST STAGER - V018 / NO PYTHON
echo ==========================================================
echo Safety: live orders stay OFF; no API keys; no private endpoints.
echo This stages exactly one test patch ZIP for Bali's updater.
echo.

if exist "%KNOWN_ROOT%\shared_data" set "ROOT=%KNOWN_ROOT%"
if not defined ROOT (
  echo Searching Desktop for Bali app folder...
  for /d %%D in ("%USERPROFILE%\Desktop\BALI_ROCKET_CRYPTO_COMMAND*") do (
    if exist "%%~fD\bali_rocket_crypto_command_v011b\shared_data" set "ROOT=%%~fD\bali_rocket_crypto_command_v011b"
    if exist "%%~fD\shared_data" set "ROOT=%%~fD"
  )
)

if not defined ROOT (
  >"%DESKTOP_REPORT%" echo RESULT=FAIL_BALI_ROOT_NOT_FOUND
  >>"%DESKTOP_REPORT%" echo EXPECTED=%KNOWN_ROOT%
  >>"%DESKTOP_REPORT%" echo PYTHON_USED=NO
  notepad "%DESKTOP_REPORT%"
  exit /b 1
)

set "REPORTS=%ROOT%\shared_data\reports"
set "UPDATE_INBOX=%ROOT%\UPDATE_INBOX"
set "HELD=%UPDATE_INBOX%\_held_by_v018_auto_test_%RANDOM%"
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%UPDATE_INBOX%" mkdir "%UPDATE_INBOX%" >nul 2>nul

if not exist "%HELPER%%PATCH_ZIP%" (
  >"%DESKTOP_REPORT%" echo RESULT=FAIL_PATCH_ZIP_MISSING_FROM_HELPER_FOLDER
  >>"%DESKTOP_REPORT%" echo EXPECTED=%HELPER%%PATCH_ZIP%
  >>"%DESKTOP_REPORT%" echo ROOT=%ROOT%
  >>"%DESKTOP_REPORT%" echo PYTHON_USED=NO
  notepad "%DESKTOP_REPORT%"
  exit /b 1
)

REM Hold every existing ZIP so the queue contains exactly one patch.
mkdir "%HELD%" >nul 2>nul
for %%Z in ("%UPDATE_INBOX%\*.zip") do move /y "%%~fZ" "%HELD%\" >nul 2>nul
copy /y "%HELPER%%PATCH_ZIP%" "%UPDATE_INBOX%\%PATCH_ZIP%" >nul

set "ZIP_COUNT=0"
for %%Z in ("%UPDATE_INBOX%\*.zip") do set /a ZIP_COUNT+=1

(
  echo BALI V018 AUTO ONE CLICK TEST REPORT
  echo Generated: %DATE% %TIME%
  echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
  echo PYTHON_USED=NO
  echo ACTION=STAGED_ONE_CLEAN_NATIVE_V016_PATCH_FOR_UPDATE_DOCK_TEST
  echo ROOT=%ROOT%
  echo UPDATE_INBOX=%UPDATE_INBOX%
  echo PATCH_ZIP=%PATCH_ZIP%
  echo PATCH_COPIED_TO=%UPDATE_INBOX%\%PATCH_ZIP%
  echo OLD_ZIPS_HELD_AT=%HELD%
  echo QUEUED_ZIP_COUNT=%ZIP_COUNT%
  echo EXPECTED_NEXT_STEP=START_BALI_AND_CLICK_APPLY_ZIP_ALREADY_IN_UPDATES
  echo EXPECTED_IF_ACCEPTED=V016_NATIVE_SCORECARD_REPORT_WRITTEN
  echo EXPECTED_IF_REJECTED=VERSION_STAYS_V015A_AND_NEXT_PATCH_NONE_WAITING
  echo RESULT=READY_TO_TEST_BALI_AUTO_ONE_CLICK_UPDATE_SYSTEM
) > "%DESKTOP_REPORT%"
copy /y "%DESKTOP_REPORT%" "%REPORTS%\BALI_V018_AUTO_ONE_CLICK_TEST_REPORT.txt" >nul 2>nul

notepad "%DESKTOP_REPORT%"

echo.
echo RESULT: READY_TO_TEST_BALI_AUTO_ONE_CLICK_UPDATE_SYSTEM
echo Queued ZIP count: %ZIP_COUNT%
echo.
echo NOW DO THIS:
echo 1^) Close Bali completely.
echo 2^) Start Bali normally.
echo 3^) Click Apply ZIP Already in Updates.
echo 4^) Click Show / Copy Tiny Final Status.
echo 5^) Paste both reports into ChatGPT.
echo.
pause
exit /b 0
