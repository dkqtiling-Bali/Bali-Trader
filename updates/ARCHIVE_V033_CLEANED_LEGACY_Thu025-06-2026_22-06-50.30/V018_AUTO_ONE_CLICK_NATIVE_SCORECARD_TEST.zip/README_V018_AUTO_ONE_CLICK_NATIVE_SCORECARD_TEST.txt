V018 Auto One Click Native Scorecard Test - No Python

Purpose:
This package tests Bali's existing Update Dock / one-click updater using a payload that already proved it can install locally without Python.

Run:
BALI_STAGE_AUTO_ONE_CLICK_V016_TEST_NOW.bat

Then:
1. Close Bali completely.
2. Start Bali normally.
3. Click Apply ZIP Already in Updates.
4. Click Show / Copy Tiny Final Status.
5. Paste the tiny status and BALI_V018_AUTO_ONE_CLICK_TEST_REPORT.txt into ChatGPT.

Safety:
- Live orders stay OFF.
- No API keys are added.
- No private exchange endpoints are used.
- Champion Council stays locked.
- The patch is report/scorecard only.
