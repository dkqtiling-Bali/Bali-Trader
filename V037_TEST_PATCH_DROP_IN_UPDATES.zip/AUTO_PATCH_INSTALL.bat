@echo off
setlocal EnableExtensions
set "APP=%~1"
set "BASE=%~2"
set "REPORTS=%~3"
if "%APP%"=="" exit /b 11
if "%BASE%"=="" exit /b 12
if "%REPORTS%"=="" exit /b 13
if not exist "%REPORTS%" mkdir "%REPORTS%" >nul 2>nul
if not exist "%APP%\tools" mkdir "%APP%\tools" >nul 2>nul
> "%REPORTS%\BALI_V037_TEST_PATCH_RESULT.txt" echo BALI V037 TEST PATCH RESULT
>> "%REPORTS%\BALI_V037_TEST_PATCH_RESULT.txt" echo Generated: %date% %time%
>> "%REPORTS%\BALI_V037_TEST_PATCH_RESULT.txt" echo SAFETY=LIVE_ORDERS_OFF ^| CHAMPION_LOCK_LOCKED ^| NO_API_KEYS
>> "%REPORTS%\BALI_V037_TEST_PATCH_RESULT.txt" echo VERSION=V037_TEST_PATCH
>> "%REPORTS%\BALI_V037_TEST_PATCH_RESULT.txt" echo RESULT=PASS_V037_TEST_PATCH_INSTALLED
> "%APP%\tools\V037_TEST_PATCH_MARKER.txt" echo V037_TEST_PATCH_MARKER=PASS
exit /b 0
