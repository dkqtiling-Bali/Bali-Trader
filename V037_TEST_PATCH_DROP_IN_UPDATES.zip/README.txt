Drop this ZIP into the outer updates folder and launch BALI_THEMED_FOREVER_STARTER.bat after V037 is installed.
