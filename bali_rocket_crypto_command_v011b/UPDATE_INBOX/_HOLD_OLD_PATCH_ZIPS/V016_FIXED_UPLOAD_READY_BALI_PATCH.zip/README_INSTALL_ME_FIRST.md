# V016 Upload-Ready Fixed Patch

This is a cleaned and stricter upload-ready rebuild of V016 Evidence Scorecard + Champion Council Gate.

It exists because the dashboard still showed `Installed: V015A_BACKTEST_WALK_FORWARD_GATE` and `Next patch: none waiting`, meaning the patch had not been accepted into the local Bali update path yet.

## What is fixed in this ZIP

- All patch files are at ZIP root for easier Update Dock detection.
- Manifest aliases are included: `PATCH_MANIFEST.json`, `patch_manifest.json`, `BALI_PATCH_MANIFEST.json`, and `manifest.json`.
- Python cache and pytest cache files are excluded.
- A local installer and verifier are included.
- V016 remains paper/research-only and cannot enable live orders.

## Safe install path

Use the Bali dashboard:

1. Click the file chooser beside `No file chosen`.
2. Select this ZIP: `V016_FIXED_UPLOAD_READY_BALI_PATCH.zip`.
3. Click `Upload Patch ZIP + Auto Restart`.
4. After restart, click `Show / Copy Tiny Final Status`.

Alternative manual path:

1. Copy this ZIP to the Bali `UPDATE_INBOX` folder.
2. Click `Apply ZIP Already in Updates`.

## Manual recovery path if the dashboard still rejects the ZIP

Extract the ZIP into the Bali app root and run:

```bash
python install_v016_upload_ready.py
python verify_v016_upload_ready.py
```

A correct install writes:

- `evidence_scorecard_v016.py`
- `shared_data/reports/v016_evidence_scorecard.json`
- `shared_data/reports/v016_evidence_scorecard.md`
- `shared_data/reports/V016_UPLOAD_READY_INSTALLED.txt`

Expected current gate is still `CHAMPION_NOMINATION_BLOCKED`; that is correct because current evidence is not yet edge-proven.
