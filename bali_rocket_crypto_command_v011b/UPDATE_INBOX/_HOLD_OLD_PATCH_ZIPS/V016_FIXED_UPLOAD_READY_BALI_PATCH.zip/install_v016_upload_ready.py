"""
V016 upload-ready local installer for Bali Rocket Crypto Command.

Safe behavior only:
- Does not enable live orders.
- Does not add API keys.
- Does not call private exchange endpoints.
- Does not mark a champion as approved.
- Writes only V016 evidence scorecard artifacts.
"""

from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from evidence_scorecard_v016 import VERSION, evaluate_status_report, parse_status_report

PATCH_ID = "V016_EVIDENCE_SCORECARD_CHAMPION_COUNCIL_GATE_UPLOAD_READY"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def find_status_report(root: Path) -> Path | None:
    candidates = []
    names = [
        "Bali.txt",
        "BALI_CHATGPT_STATUS_REPORT.txt",
        "bali_status_report.txt",
        "CHATGPT_STATUS_REPORT.txt",
    ]
    for name in names:
        p = root / name
        if p.exists() and p.is_file():
            candidates.append(p)
    reports = root / "shared_data" / "reports"
    if reports.exists():
        patterns = ["*STATUS*.txt", "*status*.txt", "*CHATGPT*.txt", "*.txt"]
        for pattern in patterns:
            candidates.extend([p for p in reports.glob(pattern) if p.is_file()])
    if not candidates:
        return None
    candidates = sorted(set(candidates), key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0]


def main() -> int:
    root = Path.cwd()
    src_module = Path(__file__).with_name("evidence_scorecard_v016.py")
    if not src_module.exists():
        print("ERROR: evidence_scorecard_v016.py missing beside installer")
        return 2

    target_module = root / "evidence_scorecard_v016.py"
    if src_module.resolve() != target_module.resolve():
        shutil.copy2(src_module, target_module)

    reports_dir = root / "shared_data" / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    status_path = find_status_report(root)
    install_record = {
        "patch_id": PATCH_ID,
        "version": VERSION,
        "installed_utc": utc_now(),
        "cwd": str(root),
        "live_orders": "OFF_UNCHANGED",
        "api_keys": "NONE_ADDED",
        "private_exchange_endpoints": "NONE_ADDED",
        "champion_claim_allowed": False,
        "status_report_used": str(status_path) if status_path else None,
    }

    if status_path:
        text = status_path.read_text(encoding="utf-8", errors="replace")
        parsed = parse_status_report(text)
        scorecard = evaluate_status_report(parsed)
        (reports_dir / "v016_evidence_scorecard.json").write_text(scorecard.to_json() + "\n", encoding="utf-8")
        (reports_dir / "v016_evidence_scorecard.md").write_text(scorecard.to_markdown(), encoding="utf-8")
        install_record.update(
            {
                "scorecard_gate": scorecard.gate,
                "overall_status": scorecard.overall_status,
                "nomination_allowed": scorecard.nomination_allowed,
                "champion_claim_allowed": scorecard.champion_claim_allowed,
                "blocking_checks": scorecard.summary.get("blocking_checks", []),
            }
        )
        print(
            "Evidence Scorecard: "
            f"{VERSION} | gate={scorecard.gate} | "
            f"nomination_allowed={scorecard.nomination_allowed} | "
            f"champion_claim_allowed={scorecard.champion_claim_allowed}"
        )
    else:
        install_record.update(
            {
                "scorecard_gate": "NOT_RUN_NO_STATUS_REPORT_FOUND",
                "overall_status": "INSTALLED_MODULE_ONLY",
                "nomination_allowed": False,
                "champion_claim_allowed": False,
                "blocking_checks": ["No compact status report found at install time"],
            }
        )
        print("Evidence Scorecard module installed. No compact status report found, so scorecard was not run.")

    print("Champion Council Gate: LOCKED_EVIDENCE_SCORECARD_REQUIRED | approvals=0/3 | live_orders=OFF | risk_police=ARMED")
    (reports_dir / "V016_UPLOAD_READY_INSTALLED.txt").write_text(
        json.dumps(install_record, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
