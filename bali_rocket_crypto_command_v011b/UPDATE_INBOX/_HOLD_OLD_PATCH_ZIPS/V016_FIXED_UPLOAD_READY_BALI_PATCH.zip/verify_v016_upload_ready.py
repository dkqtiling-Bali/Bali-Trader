"""Verify the V016 upload-ready patch without enabling trading."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from evidence_scorecard_v016 import VERSION, evaluate_status_report, parse_status_report


def main() -> int:
    root = Path.cwd()
    module = root / "evidence_scorecard_v016.py"
    reports_dir = root / "shared_data" / "reports"
    installed_record = reports_dir / "V016_UPLOAD_READY_INSTALLED.txt"
    sample = root / "V016_SCORECARD_SAMPLE.json"

    problems = []
    if not module.exists():
        problems.append("missing evidence_scorecard_v016.py")
    if sample.exists():
        data = json.loads(sample.read_text(encoding="utf-8"))
        if data.get("champion_claim_allowed") is not False:
            problems.append("sample champion_claim_allowed is not false")
        if data.get("gate") != "CHAMPION_NOMINATION_BLOCKED":
            problems.append("sample gate is not blocked")
    if installed_record.exists():
        rec = json.loads(installed_record.read_text(encoding="utf-8"))
        if rec.get("champion_claim_allowed") is not False:
            problems.append("installed record champion_claim_allowed is not false")

    if problems:
        print("V016 VERIFY: FAIL")
        for problem in problems:
            print("- " + problem)
        return 1

    print(f"V016 VERIFY: PASS | {VERSION} | live_orders=OFF | champion_claim_allowed=False")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
