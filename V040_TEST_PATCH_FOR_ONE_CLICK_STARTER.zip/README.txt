V040 test patch. This file is applied by BALI START HERE - ONE CLICK.bat.
